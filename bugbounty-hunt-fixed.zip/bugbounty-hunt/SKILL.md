---
name: bugbounty-hunt
description: >
  Full bug bounty hunting workflow: recon, subdomain takeover check, vulnerability
  scanning (info disclosure, XSS, SQLi, SSTI, SSRF, command injection, RCE, HTML
  injection), then authenticated testing (IDOR, BAC, ATO, auth bypass, logic bugs,
  CSRF). Use this whenever the user says "hunt {target}", "scan", "start recon",
  or names a domain/program to test. Only operate on domains the user confirms
  are in-scope for an authorized bug bounty program.
allowed-tools: Bash(subfinder:*), Bash(chaos-client:*), Bash(dnsx:*), Bash(httpx:*), Bash(naabu:*), Bash(alterx:*), Bash(nuclei:*), Bash(katana:*), Bash(mapcidr:*), Bash(shuffledns:*), Bash(interactsh-client:*), Bash(tlsx:*), Bash(urlfinder:*), Bash(asnmap:*), Bash(cdncheck:*), Bash(notify:*), Bash(uncover:*)
---

# Bug Bounty Hunt — Full Workflow

You are assisting Abdullah (@al1an on HackerOne) in testing bug bounty programs he is formally authorized to test. Follow the phases in order, and stop at each checkpoint below to present results and get the user's decision before continuing.

## Ground Rule Before Anything Else (Scope Gate)

Before running any tool:
1. Ask the user (if not already clear from the request) for the target/program name.
2. Confirm the domain is explicitly declared in-scope in the program's policy (HackerOne policy page). If unsure, ask the user to confirm or provide the scope link.
3. Create a `scope.md` file in the working directory documenting: program name, allowed domains/wildcards, any exclusions (out-of-scope assets), and testing limits (rate limits, allowed techniques).
4. Never send requests to an asset that isn't explicitly listed in scope.

---

## Phase 0 — Tooling Setup

Do a quick check, and if any tools from the list below are missing, install them via `pdtm`:

```bash
pdtm -install nuclei,katana,mapcidr,shuffledns,interactsh-client,interactsh-server,tlsx,urlfinder,asnmap,cdncheck,notify,proxify,uncover,vulnx,depx,aix
```

Create a target directory: `mkdir -p ~/Targets/{program_name} && cd ~/Targets/{program_name}`

---

## Phase 1 — Recon

See `references/recon.md` for full details. Order in brief:

1. **Subdomain enumeration**: `subfinder` + `chaos-client` (if you have an API key) + passive sources via subfinder (crt.sh, etc.).
2. **Permutation**: `alterx` on the results to generate additional candidates.
3. **Resolve**: `dnsx` or `shuffledns` (if you have a resolvers list) to clean out dead subdomains.
4. **Probe alive hosts**: `httpx` (title, status code, tech detection via `-td`).
5. **Port scan** (only if scope explicitly allows): `naabu` on alive hosts.
6. **TLS/cert info**: `tlsx` for extra info from certificates (additional subdomains, wildcard certs).
7. **URLs/endpoints**: `katana` (crawling) + `urlfinder` (historical URLs from archive.org/Wayback).

**Checkpoint 1 — Subdomain Takeover:**
Run a subdomain takeover check on all subdomains (not just the alive ones), since takeover is exactly caused by dangling DNS records on hosts that aren't currently live. Use nuclei's takeover-tagged templates (`-tags takeover`). If you find a positive, present it immediately and let the user decide whether to stop here for a report or continue.

---

## Phase 2 — Vulnerability Scanning

See `references/vuln-scanning.md` for detailed methodology per type, plus the dedicated deep-dive files: `references/lfi-path-traversal.md`, `references/cache-attacks.md` (poisoning & deception), and `references/saml-graphql.md` (SAML SSO bypass + GraphQL-specific issues, if the target's stack uses them). Required order:

1. Information Disclosure (exposed configs, source maps, .git, debug endpoints, verbose errors)
2. XSS (reflected/stored/DOM)
3. SQL Injection
4. SSTI (Server-Side Template Injection)
5. SSRF
6. Command Injection
7. RCE (usually a result of chaining from the above, including LFI → log poisoning)
8. HTML Injection
9. LFI / Path Traversal
10. Web Cache Poisoning & Web Cache Deception
11. SAML & GraphQL (only if applicable to the target's stack)

For each type: use `nuclei` with the relevant templates as a first-pass triage, then do manual verification of any positive before treating it as a real finding (avoid false positives).

If a promising input gets blocked by a WAF/filter instead of just being "not vulnerable", consult `references/waf-bypass.md` before writing it off — a blocked payload is a signal to adjust shape/encoding, not necessarily a dead end.

**Checkpoint 2:**
Once all these types are done, present to the user:
- A list of all findings (type, asset, preliminary severity)
- Ask: "Want me to write a report for any of these now, or move on to auth testing first?"
Do not write any report unless the user explicitly says so.

---

## Phase 3 — Authenticated Testing (IDOR / BAC / PE / ATO / Logic)

See `references/auth-testing.md`. Steps:

1. From the subdomains/assets that have a registration flow, pick the most suitable one (usually the main web app, not sub-APIs).
2. Create **two separate accounts** (User A, User B) with clearly fake test data.
3. Log the credentials in a local file (`accounts.md`) — don't share anything sensitive in chat unless necessary.
4. Test:
   - **IDOR**: swap object IDs/references between account A and B (orders, profiles, invoices, settings).
   - **BAC (Broken Access Control)**: try to reach admin-only or higher-tier-only endpoints/features, including GraphQL-specific access control gaps if applicable.
   - **PE (Privilege Escalation)**: unprotected admin mutations/endpoints, mass-assignment of role/permission fields, JWT role tampering.
   - **ATO (Account Takeover)**: password reset flow, email change flow, session fixation, OAuth/SAML misconfig, leaked tokens from cache deception.
   - **Auth Bypass**: on *every* subdomain discovered in Phase 1 (not just the main site) — try direct object access without auth headers, JWT manipulation, SAML signature wrapping if SSO is in use, etc.
   - **CSRF**: on any state-changing endpoint (especially email/password change) — check for presence/absence of CSRF tokens and SameSite cookie attributes.
   - **Logic Bugs**: anything that breaks business logic (race conditions, price manipulation, workflow bypass) across all discovered websites.

**Checkpoint 3:**
Present all findings from this phase like Checkpoint 2, and ask the user if they want reports written now.

---

## Reporting

When the user says "write a report", use a separate skill (`write-report`, if present) or follow this format:
- Summary
- Asset/Endpoint
- Severity (CVSS estimate)
- Steps to Reproduce
- Impact
- Suggested Remediation

**Do not write ready-to-run offensive exploit code inside the report** — describe the reproduction steps and the PoC needed for verification only, not an attack automation script.

---

## General Rules During Execution

- Every command you run against a real target must be within the scope you confirmed at the start.
- If any tool returns a suspicious result (potential false positive), state that explicitly before presenting it as a "finding".
- Report to the user immediately as soon as you find something serious (Critical/High) — don't wait until the entire scan is done.
- If the user says "stop" or "that's enough" at any point, stop immediately and provide a summary of progress so far.
