# WAF / Filter Bypass Techniques

General patterns collected from public bug bounty methodology write-ups. Use these as a checklist when a payload gets blocked (403, generic "Access Denied", or silently stripped) instead of giving up on a promising injection point.

## 0. Identify What You're Facing First

Before trying bypasses, fingerprint the protection layer — a technique that works on one WAF vendor usually fails on another:
- **Cloudflare**: `CF-RAY` response header, `cf_clearance`/`__cf_bm` cookies.
- **Akamai**: `akamai-grn` reference number on block pages.
- **AWS WAF / Imperva / F5**: branded block/CAPTCHA pages, generic "Access Denied" bodies.
- No vendor branding at all often means a custom regex-based filter in the app itself rather than a commercial WAF — these are usually easier to bypass since they rely on simple keyword blacklists.

## 1. Path / 403 Bypass (Broken Access Control at the edge)

When a path returns 403 but you suspect it should be reachable:
- Try appending/prepending: `/`, `//`, `/./`, `/..;/`, `/%2e/`, trailing dot, or a fake extension (`/admin.json`, `/admin.html`).
- Try alternate HTTP methods on the same path: `HEAD`, `POST`, `PUT`, `OPTIONS`, `TRACE`, or a made-up verb — some proxies only enforce rules on `GET`.
- Try header-based origin/URL overrides that some backends trust blindly: `X-Original-URL`, `X-Rewrite-URL`, `X-Forwarded-Host`, `X-Custom-IP-Authorization: 127.0.0.1`. If the reverse proxy checks the original path but the app reads one of these headers to route internally, you get a mismatch you can abuse.
- Double-slash tricks on API routes (`//api/v2/users` instead of `/api/v2/users`) sometimes desync the proxy's path matching from the backend's.
- If the target sits behind Cloudflare, check historical DNS records / old subdomains for the origin server's real IP — hitting the origin directly sometimes skips the CDN-level WAF entirely (only relevant if the origin IP itself is in scope).

## 2. XSS Filter / WAF Bypass

WAFs blocking XSS usually do one of two things: block dangerous **tags**, or block dangerous **keywords** (`alert`, `onerror`, etc.) — rarely both robustly at once. Identify which one you're facing, then target the gap:
- **Encoding**: HTML entity encoding (`&#97;` for `a`, `&#x3c;` for `<`) — the WAF scans the raw payload, but the browser decodes entities after the fact and still executes it.
- **Case variation**: `<ScRiPt>` or mixed-case event handlers bypass case-sensitive regex filters.
- **Alternate tags/vectors**: if `<script>` is blocked, try `<svg onload=...>`, `<img onerror=...>`, or other tags that support event handlers.
- **Alternate function names**: if `alert()` specifically is blacklisted (very common, since it's the default PoC function), try `confirm()` or `prompt()` to prove execution without tripping the specific keyword rule.
- **CSP gaps**: if a CSP allows external stylesheets but not scripts, injecting a remote stylesheet reference (`<link>`) can still leak data or manipulate rendering; check `frame-ancestors` for wildcard subdomain trust that includes an unclaimed/attacker-controlled host.

## 3. SQL Injection WAF Bypass

Most SQLi WAF rules are pattern/keyword based and can be defeated by changing the *shape* of the payload while keeping the same logic:
- **Inline comments** to break up blocked keywords: `UN/**/ION SEL/**/ECT`.
- **Whitespace alternatives**: replace spaces with `/**/`, tabs, or newlines — most SQL engines treat them the same, but naive filters expect a single-line pattern.
- **Parentheses instead of spaces** around logic: `OR(1=1)` instead of `OR 1=1` changes the regex match without changing the result.
- **Case randomization**: `SeLeCt`, `oR` — bypasses filters using case-sensitive matching, since SQL keywords themselves are case-insensitive to the engine.
- **Function synonyms**: `substring()`→`mid()`/`substr()`, `ascii()`→`hex()`/`bin()`, `benchmark()`→`sleep()` — useful when a WAF blacklists specific function names.
- **Alternate comparison operators**: `!=`, `<>`, `<=>` instead of `=`/`OR 1=1` for blind boolean-based payloads.
- **Always add context headers** (`Origin`, `Referer`, `X-Requested-With`) matching a legitimate request — some WAF rules are laxer on requests that look like normal AJAX calls from the app itself.
- If automated tools (sqlmap/ghauri) get blocked outright, slow down (`--delay`, `--time-sec`) — some WAFs rate-limit or fingerprint based on request burst patterns, not just payload content.

## 4. SSRF Filter Bypass

- **Open redirect chaining**: if the target blocks direct requests to internal ranges but follows redirects, host a `30x` redirect to the internal target on infrastructure you control.
- **Alternate IP notations** for loopback/internal ranges: decimal (`2130706433` for `127.0.0.1`), octal, hex, or IPv6-mapped forms — many blocklists only pattern-match the dotted-decimal form.
- **DNS rebinding**: a domain that resolves to a public IP at validation time and an internal IP at request time defeats naive "resolve-then-check" validation.
- Blind SSRF (no visible response) can still be confirmed and scored via out-of-band callbacks (`interactsh-client`) and via timing/behavioral differences (timeout vs. instant refusal vs. connection reset).

## 5. General Principles

- WAF bypass is about changing the **shape** of a payload while preserving its **logic** — the target behavior never changes, only how it's encoded/structured to slip past pattern matching.
- Combine multiple small techniques (encoding + case + comment insertion) rather than relying on one trick.
- Document, for the report, exactly which bypass worked and why the underlying filter logic was insufficient (e.g. "blacklists `alert()` but not other JS functions", "checks raw tags but not HTML-entity-encoded ones") — this is what makes a report land as a strong finding instead of "WAF blocked me, so nothing here."
- Never assume public availability of a technique implies permission to use it destructively; the goal is always proof of concept, not damage.
