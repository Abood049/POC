# CSRF Bypass Techniques & Business Logic / Race Condition Bugs

## Part 1 — CSRF Bypass Techniques

Don't stop testing CSRF just because you see a token — a large fraction of real findings are on applications that *have* CSRF protection but implement it wrong.

### Token Validation Bypasses

- **Blank/removed token**: submit the request with the CSRF token parameter empty or removed entirely — some backends only validate the token *if present*, silently skipping the check otherwise.
- **Token not actually checked server-side**: submit a request with your own account's token value, or a completely random string of the same length — if the request still succeeds, the token is decorative.
- **Session-fixation-driven CSRF**: if the app validates that the token in the request body matches the token in a *cookie* (double-submit pattern) rather than a server-side session store, and you can set/fix the victim's cookie value (via a subdomain XSS, response-header injection, or a cookie-setting endpoint), you can pre-set both the cookie and the form value to a token you know, then submit the state-changing request as the victim.
- **Guessable/weak tokens**: if the token has low entropy or looks derived from predictable data (timestamp, user ID hash), try to reproduce it algorithmically instead of needing to steal it.
- **Token leak via XSS/CORS/HTML-injection elsewhere on the same origin**: an unrelated low-severity injection bug can become the delivery mechanism to read a live CSRF token and complete the attack — always consider whether a separate finding on the same target can feed this one.

### Header-Based Defense Bypasses

- **Referer/Origin only checked when present**: suppress the `Referer` header entirely using `<meta name="referrer" content="never">` in your PoC page, or by delivering the attack from a `data:` URI/redirect chain that drops the header.
- **Referer substring/prefix matching**: if validation checks that the trusted domain merely *appears* in the Referer rather than doing exact-origin matching, craft a URL where the trusted domain appears as a path segment or subdomain of an attacker-controlled domain (`https://attacker.com/https://target.com`, `https://target.com.attacker.com`).
- **Method override parameters**: if the app exposes a `_method` override parameter (common in Laravel/Symfony/Rails-style frameworks) to simulate PUT/DELETE over a plain POST/GET, check whether CSRF protection is enforced on the *effective* method or only on the literal HTTP method used.

### SameSite Cookie Bypasses

- `SameSite=Lax` still allows cookies on top-level GET navigations — if any state-changing action can be triggered via GET (should be rare, but check), a plain `<a>`/redirect-based CSRF still works even with Lax cookies set.
- `SameSite=None` without `Secure` (or simply missing the attribute on legacy code paths) removes the protection entirely — always check the actual cookie attributes rather than assuming a modern default is in place.
- Client-side CSRF pattern: even with strict SameSite and Origin checks passing (because the request comes from the trusted frontend's own JS), if a **GET-controlled sink** in the frontend (open redirect, path parameter) can be manipulated to make the frontend's own code issue an unintended authenticated POST/PUT/DELETE, that's still a valid CSRF-class bug — look at SPAs that parse imported config/dashboard data and later concatenate it into API call paths.

### Escalation Chains

- **CSRF + IDOR**: modify a victim's data by ID via a forged cross-site request.
- **CSRF + open redirect**: chain a CSRF action with a subsequent redirect to a phishing page.
- **CSRF + clickjacking**: if there's no `X-Frame-Options`/`frame-ancestors` CSP, a "blank/invalid token" response that still reflects the attempted change (even if not saved) can sometimes be completed via a clickjacking overlay that gets the victim to click "submit again" themselves, bypassing the token check through user-triggered resubmission rather than a pure cross-origin POST.
- **CSRF on login (login CSRF)**: forcing a victim to authenticate as an *attacker-controlled* account, then waiting for them to enter sensitive data (payment info, personal details) that gets associated with the attacker's account instead — often overlooked since login forms aren't always covered by the same CSRF review as "sensitive" actions.
- **CSRF → full account takeover**: the highest-value chain — CSRF on an email-change or password-change endpoint, followed by password reset using the newly-attacker-controlled email, exactly mirroring the IDOR→ATO chain in `auth-testing.md`.

---

## Part 2 — Business Logic Flaws & Race Conditions

Business logic bugs are consistently among the highest-value, least-automatable findings — scanners can't detect them because nothing is "wrong" at the HTTP/syntax level; the bug is in what the *sequence of legitimate requests* allows you to do. HackerOne data shows these bugs account for a disproportionate share of total bounty payout dollars, especially in fintech/crypto programs, precisely because they require human insight rather than fuzzing.

### Race Conditions — Core Technique

The classic pattern is Time-Of-Check to Time-Of-Use (TOCTOU): the server checks a condition (has this coupon been used? is there enough balance? is this the first submission?), then acts on it — and if you fire multiple requests fast enough, several of them can pass the check before any of them completes the "mark as used/spent" step.

**Practical exploitation:**
1. Identify a checked-then-consumed resource: coupon codes, account balance, rate-limited actions, single-use tokens, inventory counts, "add a review" limits.
2. Capture the request in Burp Repeater, send it to Intruder/Turbo Intruder.
3. Fire 10-30+ identical requests as close to simultaneously as possible — Burp's **Turbo Intruder** with a single-packet attack (all requests bundled into one TCP packet, sent at once) minimizes network jitter and dramatically improves the hit rate compared to naive parallel requests.
4. Look for multiple "success" responses where only one should have been possible.

### Real-World Patterns

- **Coupon/discount stacking**: apply the same single-use coupon dozens of times in parallel — a disclosed Stripe finding turned a legitimate one-time $20,000 fee-discount coupon into $600,000 of free transaction processing this way, and was still paid a bounty since the researcher stopped at PoC scale.
- **Multi-step flows with a race window**: any flow where step 1 sets state and step 2 consumes/verifies it (email-change-then-OTP-verify, start-payment-then-confirm) is vulnerable if you can race a *change* into the window between the two steps — e.g. starting an OTP flow with your own email, then switching the target email to the victim's before the OTP verification step completes.
- **Inventory/limited-stock races**: purchasing more of a limited-quantity item than should be possible by firing parallel purchase requests before stock decrements.
- **Financial edge-case logic**: look for off-by-one/rounding assumptions in payment logic (e.g. a "minimum deposit" rule that can be bypassed by exploiting how the server rounds or truncates small decimal amounts) combined with a race condition on the balance-update step — this class of bug requires understanding the specific business rule, not just firing generic payloads.
- **Negative/zero-quantity manipulation**: adding a negative quantity of one item to offset the price of another in the same cart/order, when the total is calculated by simple summation without a floor check.

### Non-Race Logic Bugs (Broader Checklist)

- Workflow/step skipping: can a later step in a multi-step process (checkout, KYC, onboarding) be reached directly by URL/API call, bypassing an earlier required step (payment, verification)?
- Parameter pollution / mass duplicate parameters: sending the same parameter twice with different values (e.g. two `coupon_code` fields) to see if backend and validation logic disagree on which one "wins".
- Price/quantity tampering: modifying client-supplied price or discount fields directly in the request rather than trusting server-side recalculation.
- Verification/rating abuse: can the same user rate/review the same item multiple times, or impersonate another user in a review/comment feature via ID manipulation?
- Refund/cancellation races: firing multiple cancellation requests to receive more than one refund for what should be a single transaction.

### Reporting Notes

- For race conditions, document exact request count, timing method used (Turbo Intruder single-packet vs. naive parallel), and how many "successes" you achieved out of how many attempts — this reproducibility detail is what convinces a triager the bug is real and not a fluke.
- For financial logic bugs, calculate and state the realistic financial impact at scale (as the Stripe example did) rather than just the PoC-level small amount — this is what separates a Medium-severity "interesting behavior" report from a Critical one.
