# Recon Methodology — Full Details

## 1. Subdomain Enumeration

```bash
subfinder -d {domain} -all -o subs_subfinder.txt
chaos-client -d {domain} -o subs_chaos.txt   # if you have an active API key
cat subs_subfinder.txt subs_chaos.txt | sort -u > subs_all.txt
```

If you have `asnmap`, use it to grab the company's ASN ranges and expand discovery to owned IP ranges:

```bash
asnmap -org "{company name}" -silent
```

## 2. Permutation (generating additional candidates)

```bash
alterx -l subs_all.txt -o subs_permutations.txt
```

## 3. Resolve & Clean

```bash
dnsx -l subs_all.txt -silent -o subs_resolved.txt
# or, if you have a private resolvers list:
shuffledns -d {domain} -w subs_permutations.txt -r resolvers.txt -o subs_shuffledns.txt
```

## 4. Probe Alive Hosts

```bash
httpx -l subs_resolved.txt -title -status-code -tech-detect -o alive_hosts.txt
```

## 5. Port Scan (only if scope explicitly allows)

```bash
naabu -l alive_hosts.txt -top-ports 1000 -o open_ports.txt
```

## 6. TLS/Certificate Recon

```bash
tlsx -l subs_resolved.txt -san -cn -silent -o tls_info.txt
```

Sometimes reveals additional subdomains not visible in passive sources (via SAN fields).

## 7. Endpoint/URL Discovery

```bash
katana -list alive_hosts.txt -jc -o crawled_urls.txt
urlfinder -d {domain} -o historical_urls.txt
```

## Subdomain Takeover Check

This is the first thing after recon, even on subdomains that aren't currently alive (since dangling DNS records are exactly what causes takeover):

```bash
nuclei -l subs_all.txt -tags takeover -o takeover_results.txt
```

If there's a positive:
1. Manually verify (open the URL, check the error message — "no such app", "There isn't a GitHub Pages site here", etc. depending on the service).
2. Document: the service name (S3, GitHub Pages, Heroku, etc.), the CNAME record, and the exact error message.
3. **Do not actually claim the resource (don't register the name/resource)** unless the program's policy explicitly allows a proof-of-concept claim, and after getting permission.

**Real-world patterns:**
- The most common source of dangling CNAMEs is decommissioned marketing/campaign microsites and old third-party integrations that were never cleaned out of DNS after a project ended — check `alterx`-generated permutations like `promo-*`, `campaign-*`, `landing-*`, `old-*`, `staging-*`, `demo-*` specifically.
- A takeover on a subdomain that looks unimportant can still be high severity if the parent domain's cookies are scoped broadly (e.g. `Domain=.example.com`) — claiming the subdomain lets you read/set cookies for the entire parent domain, which can be escalated into session hijacking on the main app.
- Always re-check subdomains found via certificate transparency / `tlsx` SAN fields separately from the main subfinder/chaos list — CT logs often surface old subdomains that were never publicly linked anywhere else.

## Notes

- Save the output of each step in a separate file (checkpoint-based) so that if the scan stops you can resume without redoing everything.
- If there's wildcard DNS (every subdomain resolves to the same IP), flag this to the user immediately, since it causes a lot of false positives in any later scan.
