# Web Cache Poisoning & Web Cache Deception

Two related but distinct bug classes. Both hinge on a mismatch between what the **cache** thinks identifies a response (the "cache key") and what the **origin server** actually uses to generate it.

## Core Concept: Unkeyed Inputs

A cache doesn't store the full request as the key — usually just the URL (and sometimes a few headers). Any header/parameter the origin server *uses* to build the response but the cache *doesn't include* in the key is an "unkeyed input". If you can influence the response via an unkeyed input, you can poison what every subsequent visitor to that same cache key receives.

### Discovery Methodology

1. Send a request with a harmless cache-buster query parameter so you don't poison real visitors while testing (e.g. `?cb=12345`, changing the value each time).
2. Add candidate headers one at a time and see if they change the response: `X-Forwarded-Host`, `X-Forwarded-Scheme`, `X-Forwarded-Proto`, `X-Host`, `X-Original-URL`, `Accept-Language`, custom cookies reflected in responses.
3. For each header that changes the response, check if the cache stores the modified version: request once with the header, then request again *without* the header (or from a different session) and see if the modified content persists (a "cache hit").
4. Confirm impact by chaining the unkeyed input to something exploitable — most commonly reflected XSS (if the header value is reflected unescaped into the HTML/JS response) or an open-redirect-driven Location header.

## Cache Poisoning — Real-World Patterns

- **Fat GET / duplicate headers**: some caches only look at the *first* instance of a duplicated header for the cache key, but the origin concatenates all instances. Sending two `X-Forwarded-Host` headers (one harmless, one malicious) can smuggle a payload past the cache-key check while still reaching the vulnerable code path.
- **Query string exclusion**: if a cache strips the query string from the key entirely, any XSS reflected via a query parameter becomes a *stored*, site-wide XSS — every visitor to that path gets the poisoned response, not just people who click a crafted link. This is one of the highest-severity outcomes since it removes the "requires user interaction" caveat that usually downgrades reflected XSS.
- **Path normalization mismatches**: if the cache normalizes `//` or `/../` differently than the origin, you can poison a path that looks unrelated to the one a real visitor requests (e.g. poisoning `/home` via a request to `/<path-traversal>/home`).
- **Error-page caching**: some setups cache 4xx/5xx responses. If an error page reflects part of the request path/headers without sanitization, and error responses are cacheable, that's a poisoning vector most testers skip because "it's just an error page".
- **DoS via cache poisoning**: if you can make the cached response for a common path an error (e.g. via a malformed header the origin can't handle), you deny service to everyone hitting that cache key, without ever touching the origin directly after the first poisoned request.

## Web Cache Deception — Real-World Patterns

Different mechanism from poisoning: here the cache is tricked into storing a **dynamic, user-specific** response (someone's account page, an API key, a CSRF token, an auth session) under a URL that *looks* like a static asset, so the *next* person who requests that same URL — including the attacker — gets served the victim's cached private data.

1. **Path confusion via delimiter characters**: request a private/dynamic path with a trailing segment that looks like a static file to the cache but is ignored by the origin's router, e.g. `/my-account/nonexistent.css` or `/my-account;nonexistent.css`. If the origin resolves everything before the delimiter (`;`, extra `/`) and returns the account page anyway, but the cache sees `.css` and caches it as a static asset — that's Web Cache Deception.
2. **Path traversal into cache keys**: sending an encoded `../` sequence that the CDN's path-matching treats as harmless but the origin's router normalizes away can result in a "wildcard" deception where an entire private API path family gets cached under a static-looking key — this pattern was responsible for a real disclosed auth-token leak in a major AI chat product.
3. **Delivery**: since deception requires the *victim* to visit the crafted URL first (to populate the cache with their private response), delivery is via a phishing link or an embedded redirect, same as reflected XSS delivery. Once the victim has visited it once, the attacker requests the identical URL and receives the cached private response.
4. **Escalation chain**: leaked CSRF token or session/auth token from a deception finding is commonly chained into CSRF (perform actions as the victim) or direct account takeover (replay the leaked auth token). Document the full chain, not just the initial leak, when reporting.

## Discovery Checklist for This Skill

- After recon, identify caching infrastructure: check for `Cache-Control`, `Age`, `X-Cache`, `CF-Cache-Status`, `Vary` response headers on a handful of representative pages.
- Test unkeyed-header poisoning on high-traffic, cacheable pages (home page, product/listing pages) — these have the highest impact if poisoned.
- Test deception on any authenticated, user-specific page (account settings, API key pages, order history) by appending static-file-looking suffixes.
- Never leave a poisoned cache entry live on a production path after confirming it — immediately re-poison with a harmless cache-buster to restore the original response for real visitors, or note in the report that a fix/cache-purge is time-sensitive.
