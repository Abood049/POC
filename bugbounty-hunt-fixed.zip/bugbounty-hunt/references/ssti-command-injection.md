# SSTI & Command Injection — Deep Dive

## Part 1 — Server-Side Template Injection (SSTI)

### Discovery

Fuzz any input that ends up rendered back in a page — profile fields, search boxes, error messages, **especially username/email fields on password-reset or account-notification flows**, since these often get piped through an email template engine server-side even when the main app doesn't obviously use templates.

Standard detection payload and how different engines respond:
```
{{7*7}}      → 49 (Jinja2, Twig sometimes)
{{7*'7'}}    → 49 in Twig, 7777777 in Jinja2 (distinguishes the two)
${7*7}       → 49 (some Java/Groovy/Velocity contexts)
<%= 7*7 %>   → 49 (ERB — Ruby)
#{7*7}       → 49 (some Java EL contexts)
```

**Important**: the same payload can evaluate successfully in more than one engine — don't conclude which engine you're dealing with from a single successful response. Confirm with an engine-specific follow-up (e.g. Jinja2-only syntax) before building an exploitation chain.

If the basic `{{ }}` syntax is filtered, alternate template delimiters exist per engine (Jinja2 line-comments via `#`, Go template `{{define}}` blocks) — check the specific engine's documentation-level syntax rather than assuming a single filtered delimiter means the input is safe.

### From Detection to RCE

The path to RCE depends entirely on which built-in objects/functions the engine exposes to templates:

- **Jinja2 (Python/Flask)**: walk the Python object hierarchy from any object's `__class__`/`__mro__`/`__subclasses__()` to reach a class that gives code execution (commonly `subprocess.Popen` or similar). Auto-escaping and quote-filtering can be bypassed using built-ins like `request` or `chr()`-based string reconstruction that avoids needing literal quote characters.
- **Twig (PHP)**: harder to reach RCE without quotes since Twig's sandboxing is stricter by default; look for `dump()`/debug functions being left enabled, or a way to call `system`-equivalent functions if the sandbox extension isn't configured.
- **Mako (Python)**: similar object-graph-walking approach to Jinja2, different specific syntax.
- **FreeMarker / Velocity (Java)**: check for exposed `Runtime.getRuntime().exec()` reachability through the object model — Java template engines vary widely in what's exposed by default.
- **Go templates (`text/template` vs `html/template`)**: `text/template` allows calling any public method directly; `html/template` auto-escapes but can sometimes be bypassed via `{{define}}`/`{{template}}` blocks that redefine output outside the escaping context.

### Real-World Patterns

- **Email/notification-triggering fields** (username at registration, "next" redirect parameter on password reset) are a disproportionately common source of real SSTI findings — these fields often get concatenated into a server-rendered email template that the main request-response path never touches, so testers who only fuzz visible page output miss them.
- **Fuzz first, identify second**: throw a broad set of template-syntax special characters (`${{<%[%'"}}%\`) at every input and watch for errors before committing to a specific engine's payload — an error message alone (even without visible template evaluation) is a strong signal worth following up on with engine-specific probes.
- SSTI that can't reach full RCE can often still be escalated to **Stored XSS** (e.g. via `{{constructor.constructor('alert(1)')()}}`-style prototype-chain tricks in JS-based template engines) or **arbitrary file read** (reading application secrets/config through the template context) — don't treat "no RCE" as "no bug."

---

## Part 2 — Command Injection

### Discovery

Look for any feature that shells out to an external binary rather than handling logic in-app: image resize/thumbnail generation, PDF/document conversion (`wkhtmltopdf`, `pandoc`, LibreOffice headless), video transcoding (`ffmpeg`), network diagnostic features exposed as a product feature (ping/traceroute/DNS-lookup tools), and archive extraction.

### Confirming Blind Command Injection

If there's no direct output, use time-based confirmation (`; sleep 10`, `| sleep 10`, `` `sleep 10` ``, depending on the shell context and separator filtering) and out-of-band confirmation (DNS/HTTP callback to your own `interactsh-client` listener) — the same OOB infrastructure used for SSRF confirmation applies here.

### Separator and Filter Bypass Patterns

If a WAF/filter blocks common separators, try alternates depending on the underlying shell:
- Separators: `;`, `|`, `&&`, `||`, newline, backticks, `$()`
- Space substitution when whitespace is filtered: `${IFS}`, `<`, `{cmd,arg1,arg2}` (brace expansion), tabs
- Blocklisted binary names: absolute paths (`/usr/bin/id` instead of `id`), wildcard globbing (`/???/??t` can resolve to `/bin/cat` on some systems), or invoking through an interpreter already present (`python -c`, `perl -e`) if the direct binary name is blocked but the interpreter isn't.

### Real-World Patterns

- Command injection is frequently reached through a **filename** parameter passed to a conversion tool rather than an obvious "command" field — e.g. uploading a file with a crafted filename containing shell metacharacters, where the backend later runs something like `convert "$filename" output.png` without proper quoting/escaping.
- Windows targets: `&`, `|`, and `cmd.exe /c` syntax differ from Linux; always confirm the OS (via banners, error messages, or prior recon) before assuming a Linux-shell payload will work.
- Command injection findings in bug bounty should stick to non-destructive proof (`id`, `whoami`, `hostname`, a DNS/HTTP OOB callback) — never write files, install persistence, or pivot further without the program's explicit scope allowing it.
