# LFI / Path Traversal / RFI — Full Chain Methodology

## Discovery

Look for any parameter that looks like it selects a file/page/template: `page`, `file`, `template`, `include`, `doc`, `lang`, `path`, `view`. Confirm with:

```
?page=/etc/passwd
?page=../../../../etc/passwd
```

`/etc/passwd` is the standard safe PoC target — it's world-readable on virtually all Linux systems and confirms file-read capability without needing anything destructive.

## Bypassing Weak Filters

If plain `../` is stripped once, try:
- Double-encoding: `..%252f..%252f`
- Non-recursive-strip defeats: `....//....//` (if the filter removes `../` once without re-checking, this collapses into `../../` after a single pass)
- Absolute path if the base directory isn't enforced
- Null byte truncation on very old/unpatched stacks (`file.php%00`) — mostly historical, rarely works on modern PHP
- Alternate slash direction on Windows targets (`..\\..\\`)

## Escalating LFI to RCE

LFI that can only *read* files is still valuable (source disclosure, config/secrets leak), but real Critical-severity reports usually chain it further:

### Chain 1: Log Poisoning (most common, most reliable)

1. Identify the web server's access log path (Apache: `/var/log/apache2/access.log` or `/var/log/httpd/access_log`; Nginx: `/var/log/nginx/access.log`).
2. Confirm you can read it via the LFI: `?page=../../../../var/log/apache2/access.log`.
3. Inject a PHP payload into a header the server logs verbatim — `User-Agent` is the classic choice since it's logged by default and rarely sanitized:
   ```
   curl -A "<?php system(\$_GET['cmd']); ?>" http://target.com/
   ```
4. Include the now-poisoned log file via the LFI sink, then pass a command via the `cmd` parameter: `?page=../../../../var/log/apache2/access.log&cmd=id`.
5. In containerized environments, log paths shift (`/var/log/containers/<pod>_<ns>_<container>-<id>.log`); log poisoning still works if logs are bind-mounted into the same container as the app.

### Chain 2: PHP Wrapper Abuse (when log poisoning isn't available)

- `php://filter` chain: if the sink only *reads* files (`file_get_contents`, `include` with output buffering) rather than executing them, `php://filter/convert.base64-encode/resource=config.php` lets you read source code that would otherwise execute and hide its contents.
- `phar://` deserialization: any filesystem function call on a `phar://` URL (even `file_exists`, `getimagesize`) can trigger PHP object deserialization if an appropriate gadget chain exists in the app's dependencies — relevant when combined with an arbitrary file upload (a "polyglot" file that's valid as both an image and a phar archive).
- `php://input` + `allow_url_include=On` (increasingly rare on modern configs, but worth a quick check): lets you `include` the raw POST body directly as PHP.

### Chain 3: Upload + Include (cleanest chain when available)

If the app has *any* file upload feature that lands a file on disk at a predictable or discoverable path, this is usually more reliable than log poisoning:
1. Upload a file with PHP content, naming/content-type it however the upload feature allows.
2. Include the uploaded file via the LFI/path-traversal sink instead of a log file.
3. This avoids the log-poisoning dependency on the app's logging format not sanitizing input.

### Chain 4: /proc/self/environ (older Apache/mod_php setups)

If `/proc/self/environ` is world-readable and the LFI sink runs in the same PHP process, the `User-Agent` header again gets reflected verbatim (this time via the process environment rather than a log file), giving the same injection-then-include pattern without needing to locate a log path.

## Path Traversal Without File Inclusion

Not every path traversal leads to RCE — sometimes it's pure information disclosure (reading `.env`, `wp-config.php`, application source, SSH keys, cloud credentials files). Still worth reporting at appropriate severity based on what's actually reachable; document exactly which sensitive files were confirmed readable.

## RFI (Remote File Inclusion)

Mostly historical on modern PHP (`allow_url_include` defaults to `Off`), but worth a quick check on legacy/unpatched targets — if enabled, the app will fetch and execute code directly from an attacker-controlled URL, which is RCE with no chain required.

## Notes for Reporting

- Always show the read-file PoC (`/etc/passwd` or similar non-destructive target) as your primary evidence.
- If you escalate to RCE, use the lightest possible proof (`id`, `whoami`, `hostname`) — don't run anything destructive or persistent (no reverse shells, no file writes outside your own test artifacts) unless the program's scope explicitly allows deeper exploitation.
- Document the full chain (LFI → poisoning technique → RCE) step by step; this is what separates a Critical report from one that gets downgraded for "theoretical impact only".
