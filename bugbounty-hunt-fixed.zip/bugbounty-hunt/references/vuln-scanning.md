# Vulnerability Scanning Methodology

Required order: Information Disclosure → XSS → SQLi → SSTI → SSRF → Command Injection → RCE → HTML Injection.

For each type: perform manual verification first using curl, httpx, dig, jq, grep and Bash. Do not use Nuclei unless the user explicitly requests it.

## 1. Information Disclosure

```bash
# Manual verification using curl/httpx
curl -isk https://target
httpx -silent -title -sc
```

Look for: `.git/`, `.env`, source maps (`.js.map`), backup files (`.bak`, `.old`, `~`), debug endpoints, exposed Swagger/API docs, verbose stack traces, open cloud storage buckets.

## 2. XSS (Reflected / Stored / DOM)

- Manually verify reflection with curl/Burp Repeater. Do not rely on Nuclei.
- Use `katana`'s crawled URLs to find input points (parameters, forms, headers reflected in the response).
- For DOM XSS: look for JS sinks that use user input without sanitization (`innerHTML`, `document.write`, `eval`, etc.) — find them in the visible code (view-source / dev tools), don't write a ready-to-fire offensive payload; document where the sink is and how the input reaches it.
- If a first-pass payload gets blocked/stripped, see `waf-bypass.md` section 2 before giving up on the input point — many "not vulnerable" inputs are actually just filtered, not fixed.
- **Real-world pattern**: unusual upload types (PDF renderers, document converters) are often overlooked XSS/HTML-injection vectors — a previewed PDF or converted document can execute script in the context of whoever views it later (admin dashboards, support portals). Worth checking on any target with file upload + preview features.
- **Real-world pattern**: two individually "low impact" XSS findings on different subdomains of the same app can sometimes be chained (e.g. one steals an OAuth code, the other abuses a trusted browser permission) into a much higher-severity session hijack — don't dismiss a self-XSS or low-impact reflected XSS until you've checked what trust relationships exist between subdomains.

## 3. SQL Injection

- Nuclei triage: `-tags sqli`.
- For any suspicious parameter, test behavior-based indicators (error messages, response time changes, content changes) instead of building a complete ready-to-exploit payload.
- Document the parameter and the evidence (not the full payload if it's destructive).
- If a strict WAF blocks obvious payloads (single quotes, `OR 1=1`), see `waf-bypass.md` section 3 for shape-changing techniques (comments, case, whitespace alternatives, function synonyms) before ruling the parameter out.
- **Real-world pattern**: for bug bounty (as opposed to a full pentest), scope the impact to what's needed to prove the bug — current user, database name/version, or a single non-sensitive field — rather than a full dump. Programs often want proof over large-scale extraction.
- **Real-world pattern**: second-order SQLi (input stored in one place, executed unsafely somewhere else later) is frequently missed by scanners since the injection point and the execution point are different requests — worth checking anywhere user input gets stored and later displayed/processed in an admin or reporting context.

## 4. SSTI (Server-Side Template Injection)

- Look for anywhere user input is processed inside a template engine (Jinja2, Twig, Freemarker, Velocity).
- Signs: odd errors when you enter template-syntax-specific characters.
- Document the engine type found and the input location, without building a complete ready-to-run RCE payload.
- See `references/ssti-command-injection.md` part 1 for the full detection-to-RCE methodology per engine, and why username/email fields on password-reset or notification flows are a disproportionately common real-world source of SSTI.

## 5. SSRF

- Look for any feature that fetches a URL supplied by the user (webhooks, PDF/screenshot generators, image proxies, import-from-URL).
- Use `interactsh-client` as an out-of-band (OOB) listener to confirm the callback:

```bash
interactsh-client
# use the domain it gives you as the target URL in any feature that makes an outbound request
```

- If the callback succeeds, that's a confirmed SSRF. Document the next step (reaching cloud metadata, etc.) as **potential impact** in the report rather than something you actually execute against a production environment, unless scope explicitly allows it.
- If direct requests to `169.254.169.254` or `localhost`/`127.0.0.1` are blocked, see `waf-bypass.md` section 4 (redirect chaining, alternate IP notations, DNS rebinding) before concluding the target has no SSRF exposure.
- **Real-world pattern**: the highest-value SSRF entry points are rarely the obvious "paste a URL" field — look at webhook configuration, PDF/screenshot generators, link-preview features, avatar/image-import-from-URL, and OAuth/SSO metadata URL fields. Parameter names like `callback`, `return_url`, `redirect_uri`, `image_url`, `dest`, `source`, or `target` are common SSRF candidates, including when base64/URL-encoded.
- **Real-world pattern**: in cloud environments, reaching the metadata endpoint at all (even without visible IAM data) is treated as high risk by most triage teams — timing/behavioral confirmation of a blind SSRF against that endpoint is often enough to justify Critical severity, since it demonstrates the trust boundary is broken.

## 6. Command Injection

- Look for any feature that uses system calls (file conversion tools, image processing, exposed network utilities as a feature).
- Signs: unreasonable response delays, or shell-specific errors.
- Document the parameter and evidence, without executing destructive commands or modifying data.
- **Real-world pattern**: command injection is often hidden behind a filename/format parameter passed to an external binary (image resize, PDF conversion, video transcoding) rather than an obvious "run command" field — check any feature that shells out to `convert`, `ffmpeg`, `wkhtmltopdf`, `pandoc`, etc.
- See `references/ssti-command-injection.md` part 2 for separator/filter bypass patterns and blind (time-based/OOB) confirmation techniques.

## 7. RCE

RCE is usually the result of **chaining**, not direct exploitation:
- File write primitive + a place that loads that file (webshell, DLL hijack, cron)
- File read primitive + secrets/tokens that give you deeper access
- SSRF + cloud metadata + credentials
- Template injection + code execution in the engine itself
- **LFI + log poisoning**: see `references/lfi-path-traversal.md` for the full chain — this is one of the most consistently reproducible RCE paths in real bug bounty reports (inject PHP into a header the server logs, then include that log file through the LFI sink).
- **LFI + PHP wrapper abuse** (`php://filter`, `phar://` deserialization): also detailed in `references/lfi-path-traversal.md`, useful when log poisoning isn't available.

When you find a primitive, document the potential exploitation chain step by step as a **theoretical analysis** in the report. If scope allows an actual PoC, use the lightest possible evidence (e.g. `id`/`whoami` output) and don't perform any data modification or destruction.

## 8. HTML Injection

- Similar to XSS but without JS execution — look for places that render user input as raw HTML without encoding.
- Document the injection location and any potential impact (phishing via injected content, defacement).

## 9. LFI / Path Traversal

See `references/lfi-path-traversal.md` for the full methodology, filter-bypass tricks, and the RCE-escalation chains (log poisoning, PHP wrapper abuse, upload+include).

## 10. Web Cache Poisoning & Web Cache Deception

See `references/cache-attacks.md`. Test on high-traffic cacheable pages (poisoning) and any authenticated user-specific page (deception). These are easy to overlook but frequently escalate reflected XSS or session/token leaks into much higher severity findings (stored, site-wide impact or direct account takeover) — worth a dedicated pass rather than treating them as a footnote to XSS.

## 11. SAML & GraphQL (if applicable to the target's stack)

See `references/saml-graphql.md`. Only relevant if the target uses SAML SSO and/or exposes a GraphQL endpoint — check for these during recon (SSO login redirects, `/graphql` endpoints) and run this pass if present.

---

## General Rule for All Types

- Every finding must be documented with: the asset, the parameter/endpoint, the evidence, and the preliminary severity.
- If there's doubt about a false positive, state that explicitly in the summary before presenting it as a finding.
- Report immediately if you find something Critical/High — don't wait until all types are done.
