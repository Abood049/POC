# SAML Hacking & GraphQL Vulnerabilities

## Part 1 — SAML Authentication Bypass

SAML relies on the service provider (SP) trusting an XML assertion cryptographically signed by the identity provider (IdP). Nearly all real-world SAML bugs come from the SP's *signature validation logic* being weaker than it appears, not from breaking the cryptography itself.

### Discovery

1. Find the SAML endpoint (usually `/saml/acs`, `/sso/saml`, `/auth/saml/callback`, or discoverable in login redirect flows).
2. Get a legitimate, signed SAML assertion — either by logging in normally and capturing it (Burp), or in some cases from publicly accessible IdP metadata.
3. Identify which XML library/version the SP uses if visible (error messages, response headers, open-source stack fingerprinting) — specific libraries (ruby-saml, samlify, python3-saml, ADFS, OneLogin toolkits) have had disclosed signature-handling bugs.

### Signature Wrapping (XSW) — the Core Technique

The signature covers a specific XML element by its `ID`/reference, but many parsers validate the signature against *one* element while the *application logic* reads a *different* element with a similar or duplicated ID. If you can insert a second, attacker-controlled `<Assertion>` (or modify the `NameID`/`Subject`) while leaving the original signed block intact elsewhere in the document, a vulnerable parser may validate the original signature but the application processes your injected content instead.

Practical variants seen in disclosed reports:
- **Comments-in-NameID**: inserting an XML comment inside the `<NameID>` value (`user@user.com<!---->.evil.com`) exploits canonicalization algorithms that strip comments inconsistently, changing what the application reads vs. what was signed.
- **Parser differential (dual-parser bugs)**: some SP implementations use one XML parser (e.g. REXML) to *locate* the signature element and a different parser (e.g. Nokogiri/libxml2) to *extract the content that gets trusted*. If the two parsers interpret the same bytes differently (e.g. handling of malformed/ambiguous XML), you can craft a document where the "trusted" parser sees your injected assertion while the signature-checking parser validates the original.
- **Attribute pollution / namespace confusion**: duplicating attributes or using namespace prefix tricks so the validating code and the consuming code disagree about which element a given attribute belongs to.
- **Void canonicalization**: manipulating the canonicalization algorithm declared in the signature so that the "canonical form" used for verification doesn't match what's actually processed downstream.

### Practical Impact

A successful bypass typically allows forging an assertion for **any** user (including admins) once you possess **any** single validly-signed assertion from that IdP — even from an unprivileged test account, or in some cases from public IdP metadata alone. This is why SAML bypass findings are consistently rated Critical: the "cost" of the attack (needing one valid signature) is very low relative to the impact (arbitrary user impersonation).

### Testing Checklist

- Capture a normal login assertion; replay it as-is first to confirm baseline behavior.
- Try duplicating the `<Assertion>` element with a modified `NameID`, keeping the original (signed) assertion elsewhere in the document.
- Try inserting XML comments inside identity-bearing fields (`NameID`, `Subject`).
- Try sending malformed/ambiguous XML constructs (duplicate IDs, mismatched namespaces) and see if the app's behavior differs from a strict parse.
- Note: bypasses relying on a stolen assertion generally don't work against accounts protected by a second factor evaluated *after* SAML assertion in the flow — check whether MFA is enforced post-SSO.

---

## Part 2 — GraphQL Vulnerabilities

GraphQL's flexibility (client picks exactly which fields to request, can nest deeply, can batch operations) creates several vulnerability classes REST doesn't have.

### 1. Introspection

Query the schema directly to map the entire API surface, including mutations, types, and fields never exposed in the normal UI:
```
{ __schema { types { name fields { name type { name } } } } }
```
If introspection is disabled, GraphQL still often provides field-suggestion hints ("Did you mean: ...") on typo'd field names in error messages — this alone can be used to enumerate the schema field-by-field even without introspection enabled.

### 2. IDOR / Broken Access Control via Arguments

The most common and highest-value GraphQL bug class. Because developers must write custom resolvers (there's no built-in object-level authorization), any query/mutation that accepts an ID argument is a candidate:
- Swap the ID for another user's/object's ID in queries — check whether the resolver actually verifies ownership or just fetches by ID.
- **Nested field authorization gaps**: even if the top-level query is protected, nested fields on the returned object are sometimes resolved without their own authorization check — request additional fields (email, phone, internal notes) that aren't shown in the normal UI query but exist in the schema.
- **Edges vs. nodes**: some implementations authorize the "edge" (the relationship/connection) but not the "node" (the underlying object) reachable through it — worth testing both.

### 3. Mutations → Privilege Escalation

Introspection frequently reveals admin-oriented mutations (`changeUserRole`, `createAdmin`, `deleteUser`, `impersonateUser`) that exist in the schema but were only meant to be reachable by an internal admin UI — if the mutation itself has no server-side role check, calling it directly as a normal authenticated user can grant privilege escalation with no further chaining needed.

### 4. Batching Attacks

GraphQL allows multiple operations in a single HTTP request. This can be abused to:
- Bypass rate limiting (send hundreds of login/OTP-guess attempts as one batched request instead of hundreds of HTTP requests).
- Perform many state-changing mutations simultaneously, useful for race-condition-style logic bugs.

### 5. Query Depth / Complexity (DoS)

Deeply nested self-referential queries (e.g. `user { posts { author { posts { author { ... } } } } }` repeated many levels deep) can cause resource exhaustion if the server doesn't enforce a depth/complexity limit — a valid DoS finding on its own, and sometimes a useful way to confirm the backend's resolver structure.

### 6. Injection Through Resolvers

GraphQL itself doesn't sanitize inputs — resolvers ultimately call the same backend code (SQL, shell, file system) as a REST endpoint would. Any input field feeding into a database/file/system call downstream is subject to the same SQLi/command injection/SSRF testing as a normal parameter; GraphQL's structure doesn't provide any inherent protection.

### Testing Checklist

- Fingerprint GraphQL usage: look for `{}` and `\n`-heavy request bodies, or common endpoint paths (`/graphql`, `/api/graphql`, `/query`).
- Run an introspection query first; if blocked, try field-suggestion-based enumeration.
- Walk every mutation the schema reveals and check whether calling it directly (as a low-privilege authenticated user, and — carefully — unauthenticated) succeeds.
- For every query/mutation with an ID-like argument, test with User A's session and User B's ID (the same IDOR methodology as `auth-testing.md`, applied to GraphQL specifically).
- Check whether introspection/GraphiQL is left enabled specifically on staging/pre-prod environments that happen to be in scope — very common finding.
