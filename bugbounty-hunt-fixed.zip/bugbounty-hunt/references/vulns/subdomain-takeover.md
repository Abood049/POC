# Subdomain Takeover Policy

Mandatory checks:
1. dig +short CNAME host
2. dig +short TXT host

If ANY TXT record exists:
- Stop.
- Do NOT report takeover.

Continue only if:
- Dangling CNAME exists.
- No TXT records exist.
- Provider fingerprint is confirmed with curl.
- The service is actually claimable.

Use:
```bash
dig +short CNAME host
dig +short TXT host
curl -isk https://host
curl -Lsk https://host
```
Never rely on automated fingerprints or scanners alone.
