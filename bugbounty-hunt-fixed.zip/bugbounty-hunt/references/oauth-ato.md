# OAuth Account Takeover Chains

OAuth/SSO "Login with X" flows are one of the most consistently exploitable areas in bug bounty because the security depends on *both* the identity provider (Google/Facebook/etc.) and the client application implementing validation correctly — a gap in either one is often enough.

## Core Flow Recap

```
1. Client app redirects user to: IdP/oauth/authorize?client_id=...&redirect_uri=...&response_type=code&state=...&scope=...
2. User authenticates at the IdP and approves access
3. IdP redirects back to redirect_uri with an authorization code (or token, for implicit flow) and the original state value
4. Client app exchanges the code for an access token server-side (authorization code flow) or uses the token directly (implicit flow — increasingly deprecated)
```

Two parameters matter most for security: `redirect_uri` (where the sensitive code/token gets delivered) and `state` (CSRF protection for the flow itself).

## Chain 1 — Open Redirect → Stolen Authorization Code (most common, highest-value)

If the registered `redirect_uri` domain itself contains an open redirect, or the IdP's validation only checks a *prefix*/*same-domain* match rather than an exact URI match:

1. Confirm the exact registered `redirect_uri` from a normal login request.
2. If the client's own domain has an open redirect (`https://target.com/redirect?url=...`), register that as your `redirect_uri` value with the malicious destination appended: `redirect_uri=https://target.com/redirect?url=https://attacker.com/catch`.
3. The IdP sees `https://target.com/...` and approves it as matching the registered domain — it doesn't parse the nested URL.
4. Send this crafted authorization URL to the victim. When they authenticate normally, the IdP redirects to the client's open redirect, which then bounces them to the attacker's server **with the authorization code attached** (in the URL and/or Referer header of the subsequent request).
5. The attacker's server logs the code, then exchanges it for a token via the token endpoint before the victim's browser can (codes are typically single-use and short-lived, so speed matters).
6. Report the open redirect and the OAuth chain **together** as a single finding — severity should be scored as full Account Takeover, not as the (usually low-severity-alone) open redirect.

## Chain 2 — Missing/Weak `state` Parameter

If `state` is absent, static, or not actually validated on return:

1. The flow becomes vulnerable to CSRF: an attacker can initiate their **own** OAuth login/linking flow, capture the resulting code before it's consumed, and then trick the victim into completing a request that uses the attacker's code to **link the attacker's third-party account to the victim's session** (rather than stealing the victim's account — this attaches the attacker's identity as an alternate login method for the victim's account).
2. If the linked third-party identity can subsequently be used to log in, this becomes a one-click persistent account takeover: attacker logs in later using their own linked social account and lands in the victim's account.

## Chain 3 — Authorization Code Confusion Across Clients

If the token endpoint validates the code but doesn't strictly bind it to the `client_id`/`redirect_uri` that originally requested it:

1. Capture a valid code intended for Client App A.
2. Submit it to Client App B's (or even a first-party/internal) token exchange endpoint.
3. If a token is still issued, the code→token exchange isn't properly scoped, and codes can be "laundered" across applications — potentially minting higher-privilege tokens than the original flow intended.
4. Related check: whether PKCE (Proof Key for Code Exchange) is enforced for public/native clients — its absence means a stolen code alone is sufficient, with no additional secret/verifier needed.

## Chain 4 — Reflected Data in the Callback Response

If the client app's callback page reflects the `redirect_uri` or other request parameters back into its HTML response (e.g. an error page showing "invalid redirect to: {redirect_uri}"), this can itself be an XSS vector — chaining XSS-on-the-callback-page with token/code theft, since the victim is authenticated at exactly that moment.

## Chain 5 — SSRF via OAuth Client Registration Metadata

Some OpenID/OAuth server implementations fetch attacker-supplied URLs during client registration or discovery: `logo_uri`, `jwks_uri`, `sector_identifier_uri`, `request_uris`. If the server fetches these server-side without restriction, this is an SSRF vector reachable through the OAuth registration flow specifically — worth checking on any target that allows self-service OAuth client/app registration (common in developer-platform and API-product bug bounty scopes).

## Discovery Checklist

- Capture a full, normal OAuth login flow in Burp first — identify the exact `redirect_uri`, whether `state` is present and appears random per-request, and whether PKCE parameters (`code_challenge`/`code_verifier`) are used.
- Test `redirect_uri` manipulation: exact-match bypass attempts (open redirect chaining, path traversal appended to a valid prefix, subdomain/parameter-pollution tricks) — different IdPs validate this differently, so multiple techniques are worth trying even against major providers.
- Test with `state` removed entirely, and with a reused/predictable `state` value, to check for OAuth-flow CSRF.
- If the target is itself an OAuth **provider** (not just a consumer), also test for account-linking CSRF and race conditions on the linking/unlinking endpoints.
- Always chain the finding to its real end-state (account takeover) in the report rather than stopping at "I intercepted a code" — triagers score based on final impact, not the individual primitive.
