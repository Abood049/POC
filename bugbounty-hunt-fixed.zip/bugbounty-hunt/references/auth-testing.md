# Authenticated Testing — IDOR / BAC / ATO / Logic / CSRF

## 0. Choosing the Site and the Accounts

- Choose an asset with a clear registration flow you're allowed to sign up for (confirm registration isn't explicitly prohibited by the program's policy).
- Create two accounts: **User A** and **User B** — with clearly fake data (e.g. `testuserA+bugbounty@...`).
- Log the credentials in `accounts.md` locally. Never put them anywhere that will end up in a public report.

## 1. IDOR (Insecure Direct Object Reference)

For every feature that returns/modifies data tied to an ID (orders, invoices, profile settings, messages, uploaded files):

1. Log in as User A, get the ID of their resource.
2. Log in as User B (separate session), try to access the same resource using A's ID.
3. Test on: GET (read data), PUT/PATCH (modify), DELETE (delete).
4. Also test sequential/predictable IDs (incrementing/decrementing the number) and UUIDs (if guessable from elsewhere in the app).
5. Check auth headers/tokens themselves for embedded object references — some apps base64-encode a user ID pair directly into an auth header; decoding and swapping the victim's ID back in can bypass a check that only validates the header's *format*, not its *ownership*.
6. If an IDOR only returns a generic error on the obvious endpoint, look for a **secondary** endpoint that changes the same underlying data with weaker validation (e.g. the "view profile" endpoint is protected, but "update profile" via a different route isn't) — the highest-value IDOR chains found in public write-ups are consistently: profile/email IDOR → attacker changes victim's email to their own → attacker triggers password reset → full account takeover.
7. Don't stop at the first IDOR — mapping the whole app once you're authenticated as two separate users usually surfaces multiple instances of the same underlying access-control gap (uploads, group membership, approvals, shared documents are common repeat offenders).

## 2. Broken Access Control (BAC)

- Try to reach endpoints/features meant to be restricted to a higher tier (Pro/Enterprise) or admin, using a normal user account.
- Try changing role/permission parameters in requests (if present in body/headers).
- Check the API endpoints discovered during recon that aren't visible in the normal UI — these are often missing full access control.
- If the target exposes GraphQL, run the BAC-specific methodology in `references/saml-graphql.md` part 2 — GraphQL's per-field resolver model means access control gaps are common on nested fields and mutations even when the top-level query looks protected.

## 2b. Privilege Escalation (PE)

- **Horizontal**: covered under IDOR/BAC above — accessing another same-tier user's data/actions.
- **Vertical**: look specifically for admin-only mutations/endpoints exposed in API schemas or JS bundles (e.g. `changeUserRole`, `createAdmin`, `deleteUser`) that lack a server-side role check — calling them directly as a low-privilege user is a direct privilege escalation with no further chaining needed.
- Check for mass-assignment: if an update-profile/update-settings endpoint accepts a JSON body, try adding fields that shouldn't be client-settable (`role`, `isAdmin`, `permissions`, `tier`) even if they're not shown in the normal form — some frameworks bind all matching fields automatically unless explicitly excluded.
- Check JWTs for a role/permission claim that can be modified client-side if the signature isn't properly verified (see Auth Bypass below).

## 3. Account Takeover (ATO)

Review all of these flows:
- **Password reset**: Is the token guessable? Does it properly verify ownership? Is there rate limiting?
- **Email change**: Does it require confirmation on the new email before activating? Is there CSRF protection?
- **Session management**: Is the session invalidated after a password change? Is there session fixation?
- **OAuth/SSO**: Is there state parameter validation? Is the redirect_uri manipulable (open redirect → token theft)?
- If the target has any "Login with Google/Facebook/etc." or is itself an OAuth provider, run the full methodology in `references/oauth-ato.md` — open-redirect-chained authorization code theft and missing/weak `state` validation are two of the most consistently reproducible ATO chains across bug bounty programs, including on major providers.

## 4. Auth Bypass Across All Subdomains

From the list of subdomains that came out of recon (not just the main site):
- Try reaching any API/admin panel with no auth headers at all.
- If there's a JWT, check: `alg: none`, whether the payload can be modified without the signature changing (if the secret is weak/exposed), expiry validation.
- Check if any old/staging subdomain uses a weaker auth mechanism than production.
- If the target uses SAML SSO, run the signature-wrapping methodology in `references/saml-graphql.md` part 1 — SAML auth bypasses are consistently rated Critical since a single valid signed assertion (even from a low-privilege test account) can sometimes be reshaped to impersonate any user, including admins.
- Check whether a Web Cache Deception finding (see `references/cache-attacks.md`) leaked a session/auth token that can be replayed directly — this is a fast path from an information-disclosure-looking bug to a full ATO.

## 5. Logic Bugs

Across all discovered websites:
- Race conditions (concurrent requests on the same resource — e.g. using a coupon twice, or withdrawing more balance than available).
- Price/quantity manipulation (modifying values in the request before they reach the backend).
- Workflow bypass (skipping a step in a multi-step process, e.g. skipping the payment step in checkout).
- See `references/csrf-logic-bugs.md` part 2 for the full race-condition methodology (Turbo Intruder single-packet attacks, TOCTOU patterns) and a broader logic-bug checklist — this class of bug is consistently among the highest-paying since it can't be found by scanners.

## 6. CSRF

On every state-changing endpoint (especially email change, password change, account settings):
- Check for a CSRF token and whether it's actually validated (try removing or changing it).
- Check cookies: `SameSite` attribute (`None`/`Lax`/`Strict`), `Secure` flag.
- If you find an unprotected endpoint, build a simple PoC (auto-submitting HTML form), but only use it against your own test accounts, never a real user's account.
- See `references/csrf-logic-bugs.md` part 1 for the full bypass-technique catalogue (blank tokens, Referer suppression, SameSite gaps, method overrides) before concluding an endpoint is properly protected — a visible token doesn't mean it's actually enforced.

## Documenting Findings

For every finding in this phase, document:
- The endpoint/feature
- The two accounts used (A/B) and the difference between them
- The exact reproducible steps
- The real impact (the worst thing someone could actually do with this bug)
