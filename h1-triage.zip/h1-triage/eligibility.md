# Core Ineligible Checklist (Stage 2)

If a finding matches one of these **and there's no unusual, demonstrated chained impact**, reject it at stage 2 — don't proceed to scope/exploitability/impact.

| Pattern | Why it's usually ineligible |
|---|---|
| Missing security headers (CSP, X-Frame-Options, etc.) alone | No demonstrated exploitation, purely a hardening recommendation |
| Self-XSS | Requires the victim to attack themselves; no realistic attacker path |
| Clickjacking without demonstrated impact | Framing alone isn't exploitation — needs a real state-changing action framed |
| CSRF on logout | No meaningful impact — logging someone out isn't a security consequence |
| Missing/weak SPF record | Doesn't by itself allow spoofing without further proof (check DMARC/DKIM together) |
| Missing/weak DMARC | Same — only matters if actual spoofing is demonstrated as deliverable to inbox |
| Missing/weak DKIM | Same as above |
| Version disclosure | Info only, not exploitation |
| Banner disclosure | Info only, not exploitation |
| Missing rate limit, reported alone | Needs a demonstrated brute-force/abuse outcome to matter |
| Weak password policy | Policy recommendation, not an exploit |
| Email enumeration | Ineligible if the specific program's policy excludes it — check program scope first |
| Cookies without secure/httponly flags, no demonstrated impact | Needs a real session-hijack or MITM scenario to matter |
| robots.txt disclosure | Public-by-design file, not a vulnerability |
| Directory listing of non-sensitive content | Only matters if it exposes sensitive data |
| Stack trace without sensitive data | Info disclosure alone, no exploitation |
| OPTIONS method enabled | Standard HTTP behavior, not a vulnerability by itself |
| TRACE method enabled | Same — needs demonstrated XST or credential capture to matter |
| Autocomplete enabled on forms | Best-practice suggestion, not exploitation |
| Tabnabbing | Rarely accepted without a demonstrated realistic phishing chain |
| Reverse tabnabbing | Same as above |
| Missing Secure flag on non-session cookies | No session/credential impact demonstrated |
| Missing HttpOnly flag without a working exploit (e.g. no XSS to read it) | Theoretical only |
| Missing SameSite flag alone | Needs a working CSRF PoC to matter, not just the flag's absence |

## How to apply this stage

- Check the finding against this table **before** thinking about severity — a Critical-sounding description ("this leaks all cookies!") can still collapse into this list if impact isn't actually demonstrated.
- The "no unusual chained impact" escape hatch is real but rare — require the user to show the actual chain (e.g. "missing SameSite + confirmed CSRF PoC changing account email" is NOT ineligible, because the CSRF is demonstrated, not theoretical).
- Also cross-check the program's own scope/policy text if the user has it — some programs explicitly reclassify items on this list as in-scope for their specific product (rare, but happens with email spoofing-focused programs, for example).
