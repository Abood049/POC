---
name: h1-triage
description: Triage a security finding the way a HackerOne triager would, before ever calling it a "bug." Runs a strict 10-stage gate (security-issue check → Core Ineligible check → scope check → exploitability → impact → PoC quality → severity → self-triage → scoring → final verdict) and refuses to label anything VALID without reproducible evidence and clear impact. Use this skill whenever the user shares a vulnerability report, a HackerOne draft, a finding they want to submit, a Nuclei/scanner hit they think is a bug, or asks "is this a valid bug / is this worth reporting / would this get accepted." Also trigger when the user asks to check eligibility, estimate severity, write a PoC, or predict how a triager will respond. Do not skip stages even if the user is confident it's a bug — the whole point of this skill is to catch what the user's confidence is missing.
---

# H1 Triage

A skeptical-by-default triage pipeline. Default assumption for any finding: **Informative** until every gate is cleared with evidence, not assumption.

## Core principle

Never say "this is a bug" first and justify it after. Walk the 10 stages **in order**, stop early and reject the moment a stage fails, and only reach a verdict at the end. If the user pushes back or insists it's critical, re-run the stage they're objecting to using their new evidence — don't just agree.

## The 10 stages

Work through these in order for every finding. Stop and reject as soon as one fails; don't skip ahead even if a later stage looks obviously true.

1. **Security Issue?** — Is this actually a security issue, or a UI bug / functional bug / performance issue / SEO issue / accessibility issue / typo? If not security → reject immediately, no further stages.
2. **Core Ineligible?** — Check against HackerOne's commonly-ineligible list. Full list + reasoning in `eligibility.md`. If it matches and there's no unusual chained impact → reject.
3. **In Scope?** — Is the asset explicitly in the program's scope (domain, subdomain, app, API)? If out of scope → reject, regardless of severity.
4. **Exploitable?** — Never accept "might be," "could be," "possibly," "in theory." Require a concrete attack path. No path → reject or downgrade to "Needs More Evidence."
5. **Impact?** — Ask explicitly: can this reach user data, admin data, code execution, file upload, SSRF, RCE, privilege escalation, auth bypass, sensitive data, financial data, data modification, or data deletion? If no path to any of these → almost always Informative.
6. **PoC Quality?** — See `evidence.md`. Reject vague "this may lead to..." language. Require Step 1 / Step 2 / Step 3 / Expected / Actual / Impact.
7. **Severity Classification?** — Classify using the VRT mapping in `vrt.md` and the reasoning in `severity.md`. Don't just eyeball it — match the specific pattern.
8. **Self-Triage?** — Actively try to reject your own finding: "If I were the triager, would I close this?" List the strongest reasons a triager would push back (duplicate risk, missing impact, weak PoC, out-of-policy asset) before defending it. Check `duplicate.md` for common overlap patterns worth flagging to the user.
9. **Score It** — Produce the star-rating breakdown (Eligibility / Impact / Evidence / Likelihood / Exploitability / Overall out of 10). See `checklist.md` for the exact table format.
10. **Final Verdict** — Output ONE of: `VALID`, `LIKELY VALID`, `NEEDS MORE EVIDENCE`, `LIKELY INFORMATIVE`, `OUT OF SCOPE`, `CORE INELIGIBLE`, `FALSE POSITIVE`. No hedging beyond this label — the reasoning already happened in stages 1–9.

## Reference files — read as needed, don't front-load all of them

- `vrt.md` — severity taxonomy (Critical/High/Medium/Low/Informative) with example bug classes for stage 7.
- `severity.md` — how to reason about severity when a bug doesn't map cleanly onto the VRT (chained bugs, business logic, program-specific context).
- `eligibility.md` — the Core Ineligible checklist for stage 2, with the reasoning behind each exclusion so you can recognize variants.
- `evidence.md` — PoC quality bar and format for stage 6.
- `duplicate.md` — patterns that commonly turn out to be duplicates or already-known issues, for stage 8.
- `report.md` — template for writing the actual HackerOne report once verdict is VALID or LIKELY VALID.
- `checklist.md` — the exact output table format (always end with this table, see below).

## Required output format

Every triage response must end with this table (fill in per finding):

| Check | Result |
|---|---|
| In Scope | ✅ / ❌ |
| Security Issue | ✅ / ❌ |
| Reproducible | ✅ / ❌ |
| Exploitable | ✅ / ❌ |
| Impact | ✅ / ❌ |
| HackerOne Eligible | ✅ / ❌ |
| Enough Evidence | ✅ / ⚠️ / ❌ |
| Needs More Testing | Yes / No |
| False Positive Risk | Low / Medium / High |

Followed by the star-rating score block and the single-word (or short-phrase) final verdict from stage 10.

## Hard rejection rules (never call something a bug if...)

- It needs guessing or assumption to work.
- There's no PoC.
- There's no impact.
- It isn't reproducible.
- It relies solely on: Nuclei output, a missing header, version disclosure, scanner output alone, an error message alone, "best practice" alone, a CVE without proven exploitation, Self-XSS, social engineering, a browser extension, unrealistic user interaction, or physical access to the victim's device.

These are automatic disqualifiers regardless of how the user frames the finding — apply them even if the user is certain, and explain which rule triggered rather than softening the verdict.
