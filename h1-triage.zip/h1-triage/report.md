# Report Template (used after verdict is VALID or LIKELY VALID)

Only produce this once the triage pipeline reaches a positive verdict. Write in formal English regardless of the conversation language.

```
## Summary
[1-2 sentence description of the vulnerability, the affected asset, and the core impact]

## Vulnerability Type
[VRT category, e.g. "Server-Side Request Forgery (Blind)"]

## Affected Asset
[exact URL / endpoint / hostname / API path]

## Severity
[Critical / High / Medium / Low] — [brief justification citing vrt.md / severity.md reasoning]

## Description
[Technical explanation of the root cause — why the vulnerability exists, what component is at fault]

## Steps to Reproduce
Step 1: ...
Step 2: ...
Step 3: ...

## Proof of Concept
[Requests, payloads, screenshots, OAST logs — per evidence.md standards]

## Expected Result
[What should happen if the system were secure]

## Actual Result
[What actually happened]

## Impact
[Concrete, specific consequence — what an attacker can achieve, who is affected, at what scale]

## Remediation Suggestion
[Optional but valuable — brief, specific fix recommendation]

## Supporting Materials
[Attached screenshots / video / Burp export references]
```

## Style notes

- Match the user's established formal-report style: precise, no hedging language, past tense for what was actually observed ("the request returned...", not "the request should return...").
- Never include speculative severity language in the report body itself — the severity line states the classification plainly, the description explains why.
- If the finding involves a chain, lay out each link of the chain as its own labeled step before the combined PoC, so a triager unfamiliar with the target can follow the logic without re-deriving it.
- Keep the technical English separate from any Arabic discussion in chat — the report itself should read as a standalone professional document a triager could act on directly.
