# Severity Reasoning (beyond the VRT table)

Use this when a finding doesn't map cleanly onto `vrt.md`.

## Questions to ask, in order

1. **What is the worst realistic outcome, demonstrated (not theoretical)?**
   Not "what's the worst thing that could theoretically happen" — what did the PoC actually prove?

2. **Who is affected?**
   - Single user, self-only → usually caps severity low (often Informative unless chained).
   - Any authenticated user → Medium/High territory.
   - Any unauthenticated user (pre-auth) → push severity up a tier vs. the same bug post-auth.
   - Admin/privileged accounts specifically → push up further.

3. **Is the impact reversible?**
   - Data deletion, financial loss, account takeover → irreversible-leaning, push higher.
   - Cosmetic/temporary state change → lower.

4. **What's the interaction requirement?**
   - Zero-click / no interaction → higher severity.
   - Requires a single click on an attacker-controlled link → still valid, moderate severity.
   - Requires multiple, unrealistic steps or social engineering coordination → downgrade, note under stage 4 exploitability concerns.

5. **Is this a chain or a single bug?**
   If chaining multiple low-severity issues together to reach real impact, classify by the **final demonstrated outcome**, and explicitly write out the chain step by step so the triager can follow it. A chain claimed but not demonstrated end-to-end should be marked "Needs More Evidence," not scored at the chain's theoretical severity.

6. **Does the program's own policy override the default VRT severity?**
   Some programs explicitly state their own severity table (common for financial/crypto programs marking IDOR or logic flaws as Critical). If the user has program policy text, defer to it and say so explicitly.

## Common overclaiming patterns to watch for

- Calling something "RCE" when it's actually a file upload without proof of execution.
- Calling something "Account Takeover" when it's actually a session artifact leak without a demonstrated hijack.
- Calling reflected input "Stored XSS" when it doesn't persist.
- Calling a rate-limit gap "Critical" without demonstrating actual brute-force success.
- Calling an internal IP/hostname leak "SSRF" without proving a request was actually made server-side.

When in doubt, classify one tier lower than the user's initial claim and require them to prove the higher tier with additional evidence.
