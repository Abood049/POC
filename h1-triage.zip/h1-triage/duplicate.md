# Duplicate Risk Patterns (Stage 8)

Used during self-triage to flag findings that are statistically likely to already be known/reported, even without access to the program's actual report history.

## High duplicate-risk patterns

- Findings discovered via generic automated scanning (Nuclei default templates, common CVE scanners) on well-known, widely-used software — if a scanner found it in minutes, dozens of other researchers likely ran the same scanner.
- Missing headers, SPF/DMARC/DKIM issues, and other Core Ineligible-adjacent findings on any popular program — these get reported constantly and are usually already triaged (often already rejected).
- Subdomain takeover candidates on well-known cloud providers (common CNAME dangling patterns like unclaimed S3/Heroku/GitHub Pages) — extremely common finding, high chance someone already reported it, though still worth checking live.
- Open redirect on generic `?redirect=` or `?next=` parameters on major platforms — one of the most commonly duplicated finding types on H1.
- Clickjacking on login/landing pages of large programs — near-universally already reported and rejected as ineligible without further chaining.
- Version/banner disclosure on default install paths.
- Findings on assets that appeared in a recent public disclosure, blog post, or conference talk about the same program — assume high overlap.

## Lower duplicate-risk patterns (more likely genuinely novel)

- Business logic flaws specific to a custom, non-generic workflow.
- Chained multi-step exploits requiring program-specific knowledge.
- Findings on recently-added or recently-changed assets (new scope additions, recent feature launches) — fewer researchers have had time to test.
- IDOR/access-control issues requiring authenticated, role-specific testing (not found by unauthenticated scanning).
- Findings discovered through manual, deep testing of a specific business flow rather than automated tooling.

## What to tell the user

- Don't claim certainty about duplication — the skill has no access to the program's actual inbox.
- Instead, flag the risk level (Low/Medium/High) and explain why, based on the patterns above.
- For High risk findings, suggest the user check if the program has a public disclosure/hall-of-fame page, or search recent write-ups mentioning the same asset/bug class, before investing more time.
- Recommend testing for a unique angle (e.g. a variation, a chain, a bypass of an existing fix) rather than abandoning a promising asset entirely just because the base finding class is common.
