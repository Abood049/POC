# Final Output Format (Stages 9-10)

Every triage run ends with exactly this structure, in this order.

## 1. Checklist table

| Check | Result |
|---|---|
| In Scope | ✅ / ❌ |
| Security Issue | ✅ / ❌ |
| Reproducible | ✅ / ❌ |
| Exploitable | ✅ / ❌ |
| Impact | ✅ / ❌ |
| HackerOne Eligible | ✅ / ❌ |
| Enough Evidence | ✅ / ⚠️ / ❌ |
| Needs More Testing | Yes / No |
| False Positive Risk | Low / Medium / High |

Use ⚠️ for "Enough Evidence" when the PoC is directionally convincing but missing one required element (e.g. a screenshot, an OAST log line, a before/after comparison) — this should usually pair with a "Needs More Evidence" or "Needs More Testing: Yes" outcome rather than a clean VALID.

## 2. Score block

```
Eligibility:      ★★★★★ (x/5)
Impact:           ★★★★☆ (x/5)
Evidence:         ★★★★★ (x/5)
Likelihood:       ★★★★☆ (x/5)
Exploitability:   ★★★★★ (x/5)

Overall: X.X/10
```

Scoring guide:
- **Eligibility** — how cleanly it clears stages 1-3 (security issue, not core-ineligible, in scope). 5 stars = clean pass on all three.
- **Impact** — severity and reach per stage 5 / severity.md. 5 stars = Critical-tier, affects many users or highly sensitive data.
- **Evidence** — PoC quality per evidence.md. 5 stars = full Step/Expected/Actual/Impact with raw request/response or OAST logs.
- **Likelihood** — how easily a real attacker would find and exploit this in practice (not just theoretically). 5 stars = trivially discoverable and exploitable at scale.
- **Exploitability** — how direct the attack path is, interaction required, preconditions needed. 5 stars = zero-click, no special preconditions.

**Overall** is not a strict average — weight Eligibility and Evidence heavily, since a report that fails either one is unlikely to be accepted regardless of how severe the theoretical impact is. A finding with weak evidence should rarely score above 6/10 overall even with critical theoretical impact.

## 3. Final verdict (stage 10)

Output exactly one of:

- `VALID`
- `LIKELY VALID`
- `NEEDS MORE EVIDENCE`
- `LIKELY INFORMATIVE`
- `OUT OF SCOPE`
- `CORE INELIGIBLE`
- `FALSE POSITIVE`

No additional hedging after this line — all reasoning belongs in stages 1-9 above it, not bolted onto the verdict itself.
