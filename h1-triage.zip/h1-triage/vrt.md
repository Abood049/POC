# VRT — Severity Taxonomy

Used in stage 7 of the triage pipeline. Match the finding to the closest bug class below. If nothing matches closely, use `severity.md` for reasoning instead of forcing a fit.

This mirrors HackerOne's public Vulnerability Rating Taxonomy structure (Critical → High → Medium → Low → Informative). It is not exhaustive — treat it as a pattern-matching reference, not a lookup table.

## Critical

- Remote Code Execution (RCE)
- SQL Injection with data extraction/modification
- Authentication Bypass (full account access without credentials)
- Account Takeover (via IDOR, token leakage, password reset flaw, etc.)
- Sensitive IDOR exposing PII/financial/admin data at scale
- Server-Side Template Injection (SSTI) with code execution
- Vertical Privilege Escalation to admin/superuser
- Payment/financial logic bypass with direct monetary impact

## High

- Stored XSS (persists and affects other users)
- Blind SSRF (confirmed via OAST, especially reaching internal infra/cloud metadata)
- XXE (especially with file read or SSRF chaining)
- Privilege Escalation (horizontal with significant data exposure, or partial vertical)
- Authentication flaws with limited but real account impact (e.g. session fixation with confirmed hijack)
- Insecure Deserialization
- SQLi with limited data exposure (blind, low-value tables)

## Medium

- Reflected XSS (requires user interaction, real-world exploitable)
- CSRF with meaningful state-changing impact (not logout/preference-only)
- IDOR with limited or non-sensitive data exposure
- Business Logic flaws with moderate impact (e.g. discount abuse, minor logic bypass)
- Open Redirect chained into something (e.g. OAuth token leakage)
- Subdomain Takeover (unclaimed but low-traffic/low-trust subdomain)

## Low

- CSP Bypass without further chaining
- Clickjacking with a demonstrated, meaningful impact (not just "iframe loads")
- Open Redirect with OAuth or token exposure but no further chain confirmed
- Rate limiting issues with confirmed brute-force impact (not just "no rate limit observed")
- Verbose error messages that leak limited internal info (paths, stack frames) without exploitable data

## Informative

- Anything with no demonstrated impact
- Theoretical vulnerabilities without a working PoC
- Missing security headers alone
- Version/banner disclosure alone
- Best-practice recommendations
- Findings that fail stage 4 (exploitability) or stage 5 (impact) but aren't explicitly Core Ineligible

## Notes on classification

- Severity is about **realized or highly-plausible impact**, not theoretical worst case. "Could lead to RCE if chained with a hypothetical future bug" is not RCE severity.
- Program-specific context matters — a Medium on one program's crown-jewel asset can be treated as High if the program's policy says so. Note this to the user rather than silently overriding VRT.
- When a bug chains two lower-severity issues into a higher-impact outcome (e.g. Open Redirect + OAuth = High), classify by the **chained outcome**, not the individual pieces — but only if the chain is actually demonstrated, not asserted.
