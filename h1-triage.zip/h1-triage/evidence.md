# Evidence & PoC Quality Bar (Stage 6)

## Reject immediately

- "This may lead to..."
- "This could potentially..."
- "An attacker might be able to..."
- "It's possible that..."
- Any PoC description that hedges instead of demonstrates.

If the user's writeup contains this kind of language, ask them for the actual reproduction steps and observed result before proceeding — don't let the pipeline continue on a hedge.

## Required structure

Every accepted PoC must be rewritten (or requested) in this format:

```
Step 1: [exact action — request sent, button clicked, payload used]
Step 2: [exact action]
Step 3: [exact action]
...
Expected: [what should happen if the app were secure]
Actual: [what actually happened — include response codes, screenshots, tokens, output]
Impact: [what this concretely allows an attacker to do, stated plainly]
```

## What counts as real evidence

- Raw HTTP request/response pairs (Burp/Repeater output).
- Screenshots or screen recordings of the actual exploit executing.
- OAST interaction logs (interactsh) for blind SSRF/XXE/RCE claims — a callback received is real evidence, a request "probably sent" is not.
- Exact payloads used, not paraphrased ("used an XSS payload" is not evidence; the literal payload string is).
- Before/after state comparison for logic flaws (e.g. balance before and after, permission before and after).

## What does NOT count as evidence

- Scanner output alone (Nuclei, Burp Active Scan, etc.) without manual verification.
- A CVE ID without proof the specific target is actually vulnerable and exploitable.
- An error message alone, without showing what sensitive data (if any) it exposed.
- Descriptions of what "should" be possible based on the tech stack, without an actual attempt.

## Reproducibility check

Ask: if a triager followed these exact steps on the same target right now, would they get the same result? If the answer depends on timing windows, race conditions, or environment specifics not documented in the PoC, flag it as "Needs More Evidence" and ask the user to document the exact conditions (timing, session state, specific account type, etc.) required to reproduce.

## Note on OAST-based findings (blind SSRF/XXE/RCE)

A confirmed out-of-band interaction (DNS/HTTP callback with the correct unique identifier, sourced from the target's own request) is strong evidence, even without a full request/response chain. But the callback log itself must be included as evidence — "I set up an interactsh listener" without the log line showing the hit is not proof.
